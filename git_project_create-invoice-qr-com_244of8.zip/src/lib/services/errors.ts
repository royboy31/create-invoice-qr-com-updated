import { PDFError } from '../pdf/types';

export function getErrorMessage(error: unknown): string {
  if (error instanceof PDFError) {
    return error.message;
  }
  if (error instanceof Error) {
    return error.message;
  }
  return 'An unexpected error occurred';
}
