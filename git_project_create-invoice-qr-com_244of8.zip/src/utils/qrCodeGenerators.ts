import { PaymentData } from '../types';

export function generatePaymentString(data: PaymentData): string {
  if (!data.iban || !data.amount) {
    throw new Error('IBAN and amount are required');
  }

  // Format amount to exactly 2 decimal places
  const formattedAmount = data.amount.toFixed(2);
  
  // Clean up input data - ensure strings and handle nulls/undefined
  const cleanIban = String(data.iban || '').replace(/\s+/g, '').toUpperCase();
  const cleanName = String(data.name || '').trim().replace(/[\n\r]/g, ' ').substring(0, 70);
  const cleanReference = data.reference ? String(data.reference).trim().replace(/[\n\r]/g, ' ') : '';
  const cleanBic = data.bic ? String(data.bic).replace(/\s+/g, '').toUpperCase() : '';
  
  // Build the EPC QR Code content
  const elements = [
    'BCD',                    // Service Tag
    '002',                    // Version
    '1',                      // Character Set (UTF-8)
    'SCT',                    // SEPA Credit Transfer
    cleanBic,                 // BIC (optional)
    cleanName,                // Recipient Name
    cleanIban,                // IBAN
    `EUR${formattedAmount}`,  // Currency + Amount
    '',                       // Purpose (not used)
    cleanReference,           // Reference
    ''                        // Additional Info
  ];

  return elements.join('\n');
}
