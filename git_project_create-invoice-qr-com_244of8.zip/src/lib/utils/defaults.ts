import { PaymentData } from '../../types';

export function getDefaultPaymentData(): PaymentData {
  return {
    name: 'ABC Company',
    iban: 'BE68539007547034',
    amount: 0,
    currency: 'EUR',
    reference: '',
    bic: 'GEBABEBB'
  };
}
