import { supabase } from '../supabase';
import { ScanRecord } from './types';

interface ScanData {
  qr_code_id: string;
  timestamp: string;
  user_agent: string;
  platform: string;
  language: string;
}

export const recordScan = async (qrCodeId: string): Promise<void> => {
  try {
    // First get the current QR code to get its scan count
    const { data: qrCode, error: fetchError } = await supabase
      .from('qr_codes')
      .select('scans')
      .eq('id', qrCodeId)
      .single();

    if (fetchError) {
      console.error('Error fetching QR code:', fetchError);
      throw fetchError;
    }

    const scanData: ScanData = {
      qr_code_id: qrCodeId,
      timestamp: new Date().toISOString(),
      user_agent: navigator.userAgent,
      platform: navigator.platform,
      language: navigator.language
    };

    // Insert the scan data
    const { error: scanError } = await supabase
      .from('scan_data')
      .insert([scanData]);

    if (scanError) {
      console.error('Error recording scan:', scanError);
      throw scanError;
    }

    // Update QR code scan count
    const { error: updateError } = await supabase
      .from('qr_codes')
      .update({ 
        scans: (qrCode?.scans || 0) + 1,
        last_scan: new Date().toISOString()
      })
      .eq('id', qrCodeId);

    if (updateError) {
      console.error('Error updating scan count:', updateError);
      throw updateError;
    }

    console.log('Scan recorded successfully');
  } catch (error) {
    console.error('Error in recordScan:', error);
    throw error;
  }
};
