import React, { memo } from 'react';
import { VCardData } from '../types';
import FormField from './common/FormField';

interface VCardFormProps {
  data: VCardData;
  onChange: (data: VCardData) => void;
}

function VCardForm({ data, onChange }: VCardFormProps) {
  const handleChange = (field: keyof VCardData) => (value: string) => {
    onChange({ ...data, [field]: value });
  };

  return (
    <div className="space-y-8">
      <div className="space-y-6">
        <h3 className="text-sm font-medium text-[#c8c2bd] pb-2 border-b border-gray-800">
          Personal Information
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            label="First Name"
            value={data.firstName}
            onChange={handleChange('firstName')}
            placeholder="John"
          />
          <FormField
            label="Last Name"
            value={data.lastName}
            onChange={handleChange('lastName')}
            placeholder="Doe"
          />
        </div>

        <div className="space-y-6">
          <FormField
            label="Mobile Number"
            value={data.mobile}
            onChange={handleChange('mobile')}
            type="tel"
            placeholder="+1 234 567 890"
          />
          <FormField
            label="Phone"
            value={data.phone}
            onChange={handleChange('phone')}
            type="tel"
            placeholder="+1 234 567 890"
          />
          <FormField
            label="Work Phone"
            value={data.workPhone}
            onChange={handleChange('workPhone')}
            type="tel"
            placeholder="+1 234 567 890"
          />
          <FormField
            label="Fax"
            value={data.fax}
            onChange={handleChange('fax')}
            type="tel"
            placeholder="+1 234 567 890"
          />
        </div>

        <FormField
          label="Email"
          value={data.email}
          onChange={handleChange('email')}
          type="email"
          placeholder="john@example.com"
        />
      </div>

      <div className="space-y-6">
        <h3 className="text-sm font-medium text-[#c8c2bd] pb-2 border-b border-gray-800">
          Company Information
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            label="Company"
            value={data.company}
            onChange={handleChange('company')}
            placeholder="Company Name"
          />
          <FormField
            label="Job Title"
            value={data.jobTitle}
            onChange={handleChange('jobTitle')}
            placeholder="Your Position"
          />
        </div>
      </div>

      <div className="space-y-6">
        <h3 className="text-sm font-medium text-[#c8c2bd] pb-2 border-b border-gray-800">
          Address
        </h3>
        
        <FormField
          label="Street"
          value={data.street}
          onChange={handleChange('street')}
          placeholder="123 Main St"
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            label="City"
            value={data.city}
            onChange={handleChange('city')}
            placeholder="City"
          />
          <FormField
            label="ZIP"
            value={data.zip}
            onChange={handleChange('zip')}
            placeholder="12345"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <FormField
            label="State"
            value={data.state}
            onChange={handleChange('state')}
            placeholder="State"
          />
          <FormField
            label="Country"
            value={data.country}
            onChange={handleChange('country')}
            placeholder="Country"
          />
        </div>
      </div>

      <div className="space-y-6">
        <h3 className="text-sm font-medium text-[#c8c2bd] pb-2 border-b border-gray-800">
          Website
        </h3>
        
        <FormField
          label="Web"
          value={data.website}
          onChange={handleChange('website')}
          type="url"
          placeholder="https://www.example.com"
        />
      </div>
    </div>
  );
}

export default memo(VCardForm);
