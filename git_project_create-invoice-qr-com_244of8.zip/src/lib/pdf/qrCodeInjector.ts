import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';

interface QRPosition {
  x: number;
  y: number;
}

export async function injectQRCode(
  originalPdf: ArrayBuffer,
  position: QRPosition,
  qrText: string = 'scan me in your bank app',
  qrSize: number = 100,
  qrCodeDataUrl: string
): Promise<Uint8Array> {
  try {
    const pdfDoc = await PDFDocument.load(originalPdf);
    const page = pdfDoc.getPages()[0];
    const { width, height } = page.getSize();

    // Convert QR code data URL to bytes
    const qrCodeImageData = qrCodeDataUrl.replace('data:image/png;base64,', '');
    const qrCodeImage = await pdfDoc.embedPng(qrCodeImageData);

    // Convert percentage positions to PDF points, accounting for QR code size
    const pdfX = (position.x / 100) * width - (qrSize / 2);
    const pdfY = height - ((position.y / 100) * height) - (qrSize / 2);

    // Calculate text position (centered above QR code)
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const fontSize = 11;
    const textWidth = font.widthOfTextAtSize(qrText, fontSize);
    const textX = pdfX + (qrSize - textWidth) / 2;
    const textY = pdfY + qrSize + 8;

    // Draw white background for better visibility
    page.drawRectangle({
      x: pdfX - 5,
      y: pdfY - 5,
      width: qrSize + 10,
      height: qrSize + fontSize + 18,
      color: rgb(1, 1, 1),
      opacity: 0.1
    });

    // Draw the text
    page.drawText(qrText, {
      x: textX,
      y: textY,
      size: fontSize,
      font,
      color: rgb(0.2, 0.2, 0.2)
    });

    // Draw the QR code
    page.drawImage(qrCodeImage, {
      x: pdfX,
      y: pdfY,
      width: qrSize,
      height: qrSize
    });

    // Draw attribution text
    const attributionText = 'Made by invoice-qr.com';
    const attributionFontSize = 8;
    const attributionWidth = font.widthOfTextAtSize(attributionText, attributionFontSize);
    page.drawText(attributionText, {
      x: pdfX + (qrSize - attributionWidth) / 2,
      y: pdfY - 15,
      size: attributionFontSize,
      font,
      color: rgb(0.17, 0.004, 0.94) // #2c01ef
    });

    return await pdfDoc.save();
  } catch (error) {
    console.error('Error injecting QR code:', error);
    throw new Error('Failed to add QR code to PDF');
  }
}
