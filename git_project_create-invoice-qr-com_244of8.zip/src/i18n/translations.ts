import { Translations } from './types';

export const translations: Translations = {
  en: {
    common: {
      upload: "Upload",
      download: "Download",
      processing: "Processing...",
      dragAndDrop: "Drop PDF here or click to upload",
      error: "Error",
      success: "Success",
      next: "Next",
      back: "Back",
      cancel: "Cancel",
      save: "Save",
      close: "Close"
    },
    invoice: {
      title: "Invoice QR Generator",
      subtitle: "Add Payment QR Code",
      description: "Process an invoice and add a standardized payment QR code compatible with Belgian, German, Austrian, and Finnish banking systems.",
      supportedBanks: "Supported Banking Systems:",
      supportedCountries: "Belgium, Germany, Austria and Finland",
      verifyWarning: "Please carefully verify all payment details before saving the PDF. The QR code will be generated based on the data shown in this form.",
      steps: {
        upload: {
          title: "Step 1",
          subtitle: "Upload Invoice",
          description: "Drop your PDF invoice or click to choose the file"
        },
        position: {
          title: "Step 2",
          subtitle: "Set QR Position",
          description: "Choose where to place the QR code on your invoice"
        },
        verify: {
          title: "Step 3",
          subtitle: "Verify Data",
          description: "Review and confirm the extracted payment information"
        },
        export: {
          title: "Step 4",
          subtitle: "Export",
          description: "Download your invoice with the QR code added"
        }
      }
    },
    payment: {
      recipientName: "Recipient Name",
      iban: "IBAN",
      amount: "Amount",
      reference: "Reference",
      currency: "Currency",
      qrText: "QR Code Text",
      qrSize: "QR Size"
    }
  },
  fr: {
    common: {
      upload: "Télécharger",
      download: "Télécharger",
      processing: "Traitement en cours...",
      dragAndDrop: "Déposez le PDF ici ou cliquez pour télécharger",
      error: "Erreur",
      success: "Succès",
      next: "Suivant",
      back: "Retour",
      cancel: "Annuler",
      save: "Enregistrer",
      close: "Fermer"
    },
    invoice: {
      title: "Générateur de QR Code pour Facture",
      subtitle: "Ajouter un QR Code de Paiement",
      description: "Traitez une facture et ajoutez un QR code de paiement standardisé compatible avec les systèmes bancaires belge, allemand, autrichien et finlandais.",
      supportedBanks: "Systèmes Bancaires Supportés :",
      supportedCountries: "Belgique, Allemagne, Autriche et Finlande",
      verifyWarning: "Veuillez vérifier attentivement tous les détails de paiement avant d'enregistrer le PDF. Le QR code sera généré sur la base des données affichées dans ce formulaire.",
      steps: {
        upload: {
          title: "Étape 1",
          subtitle: "Télécharger la Facture",
          description: "Déposez votre facture PDF ou cliquez pour choisir le fichier"
        },
        position: {
          title: "Étape 2",
          subtitle: "Définir la Position du QR",
          description: "Choisissez où placer le QR code sur votre facture"
        },
        verify: {
          title: "Étape 3",
          subtitle: "Vérifier les Données",
          description: "Vérifiez et confirmez les informations de paiement extraites"
        },
        export: {
          title: "Étape 4",
          subtitle: "Exporter",
          description: "Téléchargez votre facture avec le QR code ajouté"
        }
      }
    },
    payment: {
      recipientName: "Nom du Bénéficiaire",
      iban: "IBAN",
      amount: "Montant",
      reference: "Référence",
      currency: "Devise",
      qrText: "Texte du QR Code",
      qrSize: "Taille du QR"
    }
  },
  de: {
    common: {
      upload: "Hochladen",
      download: "Herunterladen",
      processing: "Verarbeitung...",
      dragAndDrop: "PDF hier ablegen oder klicken zum Hochladen",
      error: "Fehler",
      success: "Erfolg",
      next: "Weiter",
      back: "Zurück",
      cancel: "Abbrechen",
      save: "Speichern",
      close: "Schließen"
    },
    invoice: {
      title: "Rechnungs-QR-Generator",
      subtitle: "Zahlungs-QR-Code hinzufügen",
      description: "Verarbeiten Sie eine Rechnung und fügen Sie einen standardisierten Zahlungs-QR-Code hinzu, der mit belgischen, deutschen, österreichischen und finnischen Banksystemen kompatibel ist.",
      supportedBanks: "Unterstützte Banksysteme:",
      supportedCountries: "Belgien, Deutschland, Österreich und Finnland",
      verifyWarning: "Bitte überprüfen Sie alle Zahlungsdetails sorgfältig, bevor Sie die PDF speichern. Der QR-Code wird auf Basis der in diesem Formular angezeigten Daten generiert.",
      steps: {
        upload: {
          title: "Schritt 1",
          subtitle: "Rechnung hochladen",
          description: "Legen Sie Ihre PDF-Rechnung ab oder klicken Sie zum Auswählen"
        },
        position: {
          title: "Schritt 2",
          subtitle: "QR-Position festlegen",
          description: "Wählen Sie, wo der QR-Code auf Ihrer Rechnung platziert werden soll"
        },
        verify: {
          title: "Schritt 3",
          subtitle: "Daten überprüfen",
          description: "Überprüfen und bestätigen Sie die extrahierten Zahlungsinformationen"
        },
        export: {
          title: "Schritt 4",
          subtitle: "Exportieren",
          description: "Laden Sie Ihre Rechnung mit dem hinzugefügten QR-Code herunter"
        }
      }
    },
    payment: {
      recipientName: "Empfängername",
      iban: "IBAN",
      amount: "Betrag",
      reference: "Referenz",
      currency: "Währung",
      qrText: "QR-Code Text",
      qrSize: "QR-Größe"
    }
  },
  nl: {
    common: {
      upload: "Uploaden",
      download: "Downloaden",
      processing: "Verwerking...",
      dragAndDrop: "Sleep PDF hier of klik om te uploaden",
      error: "Fout",
      success: "Succes",
      next: "Volgende",
      back: "Terug",
      cancel: "Annuleren",
      save: "Opslaan",
      close: "Sluiten"
    },
    invoice: {
      title: "Factuur QR Generator",
      subtitle: "Betalings-QR-code toevoegen",
      description: "Verwerk een factuur en voeg een gestandaardiseerde betalings-QR-code toe die compatibel is met Belgische, Duitse, Oostenrijkse en Finse banksystemen.",
      supportedBanks: "Ondersteunde Banksystemen:",
      supportedCountries: "België, Duitsland, Oostenrijk en Finland",
      verifyWarning: "Controleer alle betalingsgegevens zorgvuldig voordat u de PDF opslaat. De QR-code wordt gegenereerd op basis van de gegevens die in dit formulier worden getoond.",
      steps: {
        upload: {
          title: "Stap 1",
          subtitle: "Factuur uploaden",
          description: "Sleep uw PDF-factuur of klik om te kiezen"
        },
        position: {
          title: "Stap 2",
          subtitle: "QR-positie instellen",
          description: "Kies waar de QR-code op uw factuur moet komen"
        },
        verify: {
          title: "Stap 3",
          subtitle: "Gegevens verifiëren",
          description: "Controleer en bevestig de geëxtraheerde betalingsgegevens"
        },
        export: {
          title: "Stap 4",
          subtitle: "Exporteren",
          description: "Download uw factuur met de toegevoegde QR-code"
        }
      }
    },
    payment: {
      recipientName: "Naam begunstigde",
      iban: "IBAN",
      amount: "Bedrag",
      reference: "Referentie",
      currency: "Valuta",
      qrText: "QR-code tekst",
      qrSize: "QR-grootte"
    }
  }
};
