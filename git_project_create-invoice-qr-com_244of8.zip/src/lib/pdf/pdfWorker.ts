import { GlobalWorkerOptions } from 'pdfjs-dist';

// Use a CDN-hosted worker file directly
GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.0.379/pdf.worker.min.js';
