export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      qr_codes: {
        Row: {
          id: string
          type: string
          content: string
          scans: number
          created_at: string
          last_scan: string | null
        }
        Insert: {
          id?: string
          type: string
          content: string
          scans?: number
          created_at?: string
          last_scan?: string | null
        }
        Update: {
          id?: string
          type?: string
          content?: string
          scans?: number
          created_at?: string
          last_scan?: string | null
        }
      }
      scan_data: {
        Row: {
          id: string
          qr_code_id: string
          timestamp: string
          user_agent: string | null
          platform: string | null
          language: string | null
        }
        Insert: {
          id?: string
          qr_code_id: string
          timestamp?: string
          user_agent?: string | null
          platform?: string | null
          language?: string | null
        }
        Update: {
          id?: string
          qr_code_id?: string
          timestamp?: string
          user_agent?: string | null
          platform?: string | null
          language?: string | null
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
