import { openai } from '../openai/client';
import { PaymentData } from '../../../types';
import { handleOpenAIError } from '../openai/errors';

export async function extractInvoiceDataWithAI(text: string): Promise<PaymentData> {
  if (!text) {
    throw new Error('No text provided for extraction');
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{
        role: "user",
        content: `Extract payment information from this invoice text. Return a JSON object with these fields:
          - name: recipient/company name
          - iban: IBAN number (if present)
          - amount: numeric amount (if present)
          - reference: invoice reference number (if present)
          - currency: payment currency (if present, default to EUR)

          Invoice text:
          ${text}`
      }],
      temperature: 0.1,
    });

    const content = response.choices[0].message?.content;
    if (!content) {
      throw new Error('No response from OpenAI');
    }

    const result = JSON.parse(content);
    return {
      name: result.name?.trim() || '',
      iban: result.iban?.replace(/\s+/g, '').toUpperCase() || '',
      amount: typeof result.amount === 'number' ? result.amount : 
              typeof result.amount === 'string' ? parseFloat(result.amount.replace(/[^\d.,]/g, '').replace(',', '.')) : 0,
      currency: result.currency?.toUpperCase() || 'EUR',
      reference: result.reference?.trim(),
      info: result.reference ? `Invoice ${result.reference}` : undefined
    };
  } catch (error) {
    handleOpenAIError(error);
  }
}
