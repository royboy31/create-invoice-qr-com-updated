import React from 'react';
import { AlertCircle, XCircle } from 'lucide-react';

interface ErrorDisplayProps {
  message: string;
  onDismiss?: () => void;
}

export default function ErrorDisplay({ message, onDismiss }: ErrorDisplayProps) {
  return (
    <div className="mt-4 p-4 bg-red-50 rounded-md">
      <div className="flex items-start">
        <AlertCircle className="h-5 w-5 text-red-400 mt-0.5" />
        <div className="ml-3 flex-1">
          <p className="text-sm text-red-700">{message}</p>
        </div>
        {onDismiss && (
          <button
            onClick={onDismiss}
            className="ml-3"
          >
            <XCircle className="h-5 w-5 text-red-400 hover:text-red-500" />
          </button>
        )}
      </div>
    </div>
  );
}
