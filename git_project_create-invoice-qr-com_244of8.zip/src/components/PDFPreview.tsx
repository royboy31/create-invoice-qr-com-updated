import React, { useRef } from 'react';
import { X } from 'lucide-react';
import PDFCanvas from './pdf/PDFCanvas';
import PDFToolbar from './pdf/controls/PDFToolbar';
import PDFEditor from './pdf/PDFEditor';
import { useZoom } from '../hooks/useZoom';
import { useDragAndDrop } from '../hooks/useDragAndDrop';
import { PDF_CONSTANTS } from '../lib/pdf/constants';

interface PDFPreviewProps {
  pdfArrayBuffer: ArrayBuffer;
  qrPosition: { x: number; y: number } | null;
  onPositionChange: (position: { x: number; y: number } | null) => void;
  onGenerate: (qrText: string, qrSize: number) => void;
  isGenerating: boolean;
  qrCodeData: string | null;
  qrText: string;
  qrSize: number;
  onQRSizeChange: (size: number) => void;
  onClose: () => void;
  onUploadAnother: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

export default function PDFPreview({
  pdfArrayBuffer,
  qrPosition,
  onPositionChange,
  onGenerate,
  isGenerating,
  qrCodeData,
  qrText,
  qrSize,
  onQRSizeChange,
  onClose,
  onUploadAnother
}: PDFPreviewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scale, zoomIn, zoomOut, resetZoom } = useZoom(1);
  const { isDragging, handlers } = useDragAndDrop({
    containerRef,
    onPositionChange
  });

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-4 py-2 border-b border-gray-200">
        <h2 className="text-lg font-medium text-gray-900">
          Set QR Position
        </h2>
        <button
          onClick={onClose}
          className="p-1 hover:bg-gray-100 rounded-full"
        >
          <X className="w-5 h-5 text-gray-500" />
        </button>
      </div>

      <PDFToolbar
        scale={scale}
        onZoomIn={zoomIn}
        onZoomOut={zoomOut}
        onResetZoom={resetZoom}
        onGenerate={() => onGenerate(qrText, qrSize)}
        isGenerating={isGenerating}
        hasQRCode={!!qrPosition}
        qrSize={qrSize}
        onQRSizeChange={onQRSizeChange}
        onUploadAnother={onUploadAnother}
      />

      <div 
        className="flex-1 relative min-h-0 overflow-hidden"
        style={{
          height: 'calc(100vh - 200px)'
        }}
      >
        <div 
          ref={containerRef}
          className="absolute inset-0 flex items-center justify-center overflow-hidden"
          {...handlers}
        >
          <PDFCanvas 
            pdfData={pdfArrayBuffer}
            maxWidth={PDF_CONSTANTS.MAX_PREVIEW_WIDTH}
          />
          
          {isDragging && !qrPosition && (
            <div className="absolute inset-0 border-2 border-dashed border-indigo-500 bg-indigo-50 bg-opacity-10" />
          )}
          
          <PDFEditor
            qrPosition={qrPosition}
            onPositionChange={onPositionChange}
            scale={scale}
            qrCodeData={qrCodeData}
            qrText={qrText}
            qrSize={qrSize}
          />
        </div>
      </div>
    </div>
  );
}
