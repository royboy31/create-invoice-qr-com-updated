export class OpenAIServiceError extends Error {
  constructor(
    message: string,
    public code: string,
    public details?: any
  ) {
    super(message);
    this.name = 'OpenAIServiceError';
  }
}

export function handleOpenAIError(error: any): never {
  console.error('OpenAI API error:', error);

  if (error?.error?.type === 'insufficient_quota') {
    throw new OpenAIServiceError(
      'AI service is currently unavailable',
      'QUOTA_EXCEEDED'
    );
  }

  if (error?.error?.type === 'invalid_request_error') {
    throw new OpenAIServiceError(
      'Invalid request to AI service',
      'INVALID_REQUEST'
    );
  }

  throw new OpenAIServiceError(
    'Failed to process with AI',
    'GENERAL_ERROR',
    error
  );
}
