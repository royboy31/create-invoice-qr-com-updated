import { SMSData } from '../../types';

export function generateSMSString(data: SMSData): string {
  if (!data.phone) throw new Error('Phone number is required');
  
  const cleanPhone = data.phone.replace(/[^\d+]/g, '');
  return `SMSTO:${cleanPhone}:${data.message || ''}`;
}
