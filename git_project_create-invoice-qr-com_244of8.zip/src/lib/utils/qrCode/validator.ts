import { PaymentData } from '../../../types';

export function validateQRCode(data: PaymentData): string[] {
  const errors: string[] = [];

  if (!data.iban) {
    errors.push('IBAN is required');
  }

  if (!data.amount || data.amount <= 0) {
    errors.push('Valid amount is required');
  }

  if (!data.name) {
    errors.push('Recipient name is required');
  }

  return errors;
}
