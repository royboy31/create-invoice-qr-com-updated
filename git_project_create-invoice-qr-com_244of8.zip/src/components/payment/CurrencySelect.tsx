import React from 'react';

interface CurrencySelectProps {
  value: string;
  onChange: (value: string) => void;
  label: string;
}

const currencies = [
  { code: 'EUR', symbol: '€', name: 'Euro' },
  { code: 'USD', symbol: '$', name: 'US Dollar' },
  { code: 'GBP', symbol: '£', name: 'British Pound' },
  { code: 'CHF', symbol: 'CHF', name: 'Swiss Franc' }
] as const;

export default function CurrencySelect({ value, onChange, label }: CurrencySelectProps) {
  return (
    <div className="relative">
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-4 py-2.5 text-sm bg-black/50 border border-gray-800 rounded-lg focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 text-[#c8c2bd] appearance-none"
      >
        {currencies.map(({ code, name }) => (
          <option key={code} value={code}>
            {code} - {name}
          </option>
        ))}
      </select>
      <label className="absolute z-10 left-2 -top-2.5 px-1 text-xs text-[#c8c2bd] bg-[#111]">
        {label}
      </label>
    </div>
  );
}
