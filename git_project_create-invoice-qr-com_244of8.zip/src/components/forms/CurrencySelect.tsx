import React from 'react';

const currencies = ['EUR', 'USD', 'GBP', 'CHF', 'JPY'] as const;

interface CurrencySelectProps {
  value: string;
  onChange: (value: string) => void;
}

export default function CurrencySelect({ value, onChange }: CurrencySelectProps) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full px-3 py-2 bg-black/50 border border-gray-800 rounded-md text-[#c8c2bd] focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
    >
      {currencies.map((currency) => (
        <option key={currency} value={currency}>
          {currency}
        </option>
      ))}
    </select>
  );
}
