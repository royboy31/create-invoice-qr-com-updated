import { PrismaClient } from '@prisma/client';
import { nanoid } from 'nanoid';

const prisma = new PrismaClient();

export const createQRCode = async (type: string, content: string) => {
  return prisma.qRCode.create({
    data: {
      id: nanoid(10),
      type,
      content
    }
  });
};

export const recordScan = async (qrCodeId: string, scanData: {
  userAgent?: string;
  platform?: string;
  language?: string;
}) => {
  return prisma.scan.create({
    data: {
      qrCodeId,
      ...scanData
    }
  });
};

export const getQRCodeWithScans = async (id: string) => {
  return prisma.qRCode.findUnique({
    where: { id },
    include: {
      scans: true
    }
  });
};

export const getQRCodesAnalytics = async () => {
  const qrCodes = await prisma.qRCode.findMany({
    include: {
      scans: true
    }
  });

  return qrCodes;
};
