import { PaymentData } from '../../../types';
import { extractInvoiceDataWithAI } from './ai';
import { extractInvoiceDataWithRegex } from './regex';

export async function extractInvoiceData(text: string): Promise<PaymentData> {
  try {
    // First try AI extraction
    const data = await extractInvoiceDataWithAI(text);
    
    // If we got valid data, ensure structured reference format is preserved
    if (data.name && data.iban && data.amount > 0) {
      // Check if reference is in structured format but missing +++
      if (data.reference && /^\d{3}\/\d{4}\/\d{5}$/.test(data.reference)) {
        data.reference = `+++${data.reference}+++`;
      }
      return data;
    }

    // Otherwise fall back to regex
    console.warn('AI extraction failed or returned incomplete data, falling back to regex');
    return extractInvoiceDataWithRegex(text);
  } catch (error) {
    console.warn('AI extraction failed, falling back to regex:', error);
    return extractInvoiceDataWithRegex(text);
  }
}
