import { PaymentData } from '../../../types';

const PATTERNS = {
  iban: [
    /(?:iban|account|konto)[\s:]*([A-Z]{2}\d{2}[A-Z0-9]{4}[0-9]{7}([A-Z0-9]?){0,16})/i,
    /([A-Z]{2}\d{2}[A-Z0-9]{4}[0-9]{7}([A-Z0-9]?){0,16})/i
  ],
  amount: [
    /(?:total|amount|sum|payable|due)[\s:]*(?:EUR|€)\s*(\d+(?:[.,]\d{2})?)/i,
    /(?:EUR|€)\s*(\d+(?:[.,]\d{2})?)/i,
    /(\d+(?:[.,]\d{2})?)\s*(?:EUR|€)/i
  ],
  name: [
    /(?:bill from|invoice from|from|sender)[\s:]*([^\n\r]+)/i,
    /(?:company|business|organization)[\s:]*name[\s:]*([^\n\r]+)/i
  ],
  structuredReference: [
    /\+\+\+(\d{3}\/\d{4}\/\d{5})\+\+\+/,
    /(\d{3}\/\d{4}\/\d{5})/
  ],
  invoiceNumber: [
    /(?:invoice|reference|ref|no\.|nummer)[\s:]*(?:number|#|nr\.?)?[\s:]*([A-Z0-9-]{3,})/i,
    /(?:facture|factuurnummer|factuur)[\s:]*([A-Z0-9-]{3,})/i
  ],
  bic: [
    /(?:bic|swift)[\s:]*([A-Z]{6}[A-Z2-9][A-NP-Z0-9](?:[A-Z0-9]{3})?)/i
  ]
};

function findMatch(text: string, patterns: RegExp[]): string {
  if (!text || typeof text !== 'string') return '';
  
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match?.[1]) {
      return match[1].trim();
    }
  }
  return '';
}

function cleanAmount(amount: string): number {
  if (!amount) return 0;
  const cleaned = String(amount).replace(/[^\d.,]/g, '').replace(',', '.');
  const parsed = parseFloat(cleaned);
  return isNaN(parsed) ? 0 : parsed;
}

function validateBIC(bic: string): boolean {
  return /^[A-Z]{6}[A-Z2-9][A-NP-Z0-9](?:[A-Z0-9]{3})?$/.test(bic);
}

function findReference(text: string): string {
  // First try to find full structured reference with +++
  const fullStructuredMatch = text.match(/\+\+\+\d{3}\/\d{4}\/\d{5}\+\+\+/);
  if (fullStructuredMatch) {
    return fullStructuredMatch[0];
  }

  // Then try to find structured reference without +++
  const structuredMatch = text.match(/\d{3}\/\d{4}\/\d{5}/);
  if (structuredMatch) {
    return `+++${structuredMatch[0]}+++`;
  }

  // Fallback to invoice number
  return findMatch(text, PATTERNS.invoiceNumber);
}

export function extractInvoiceDataWithRegex(text: string): PaymentData {
  const cleanText = String(text || '')
    .replace(/\s+/g, ' ')
    .replace(/[^\x20-\x7E]/g, ' ')
    .trim();

  const iban = findMatch(cleanText, PATTERNS.iban).replace(/\s+/g, '').toUpperCase();
  const amount = cleanAmount(findMatch(cleanText, PATTERNS.amount));
  const name = findMatch(cleanText, PATTERNS.name);
  const reference = findReference(cleanText);
  
  // Only include BIC if it's valid
  const bicMatch = findMatch(cleanText, PATTERNS.bic).replace(/\s+/g, '').toUpperCase();
  const bic = validateBIC(bicMatch) ? bicMatch : undefined;

  return {
    name,
    iban,
    amount,
    currency: 'EUR',
    reference: reference || undefined,
    bic
  };
}
