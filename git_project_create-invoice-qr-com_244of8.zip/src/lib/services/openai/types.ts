export interface ExtractedInvoiceData {
  name?: string;
  iban?: string;
  amount?: number;
  reference?: string;
  currency?: string;
  bic?: string;
}

export interface OpenAIError {
  code: string;
  message: string;
  type: string;
  param?: string;
}
