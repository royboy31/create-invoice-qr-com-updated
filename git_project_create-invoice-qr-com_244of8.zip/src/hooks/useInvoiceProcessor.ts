import { useState, useCallback } from 'react';
import { PaymentData } from '../types';
import { extractInvoiceData } from '../lib/services/openai/extractors';
import { extractTextFromPDF } from '../lib/services/pdf';
import { generateQRCode } from '../lib/utils/qrCode';
import { exportPDFWithQR } from '../lib/pdf/export';

export function useInvoiceProcessor(initialData: PaymentData) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [extractedData, setExtractedData] = useState<PaymentData | null>(null);
  const [pdfArrayBuffer, setPdfArrayBuffer] = useState<ArrayBuffer | null>(null);
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [qrPosition, setQrPosition] = useState<{ x: number; y: number } | null>(null);
  const [qrCodeData, setQrCodeData] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const resetState = useCallback(() => {
    setLoading(false);
    setError(null);
    setExtractedData(null);
    setPdfArrayBuffer(null);
    setPdfFile(null);
    setQrPosition(null);
    setQrCodeData(null);
    setIsGenerating(false);
  }, []);

  const handleFileUpload = useCallback(async (event: React.ChangeEvent<HTMLInputElement> | File) => {
    const file = event instanceof File ? event : event.target.files?.[0];
    if (!file || !file.type.includes('pdf')) {
      setError('Please upload a PDF file');
      return;
    }

    setLoading(true);
    setError(null);
    setExtractedData(null);
    setQrCodeData(null);

    try {
      const arrayBuffer = await file.arrayBuffer();
      setPdfArrayBuffer(arrayBuffer);
      setPdfFile(file);
      
      const extractedText = await extractTextFromPDF(file);
      const data = await extractInvoiceData(extractedText);
      
      if (data.name && data.iban && data.amount > 0) {
        setExtractedData(data);
        setQrPosition({ x: 50, y: 85 });
        const qrCode = await generateQRCode(data);
        setQrCodeData(qrCode);
      } else {
        setExtractedData({ ...initialData });
      }
    } catch (err) {
      console.error('Error processing file:', err);
      setError(err instanceof Error ? err.message : 'Failed to process invoice');
      setExtractedData({ ...initialData });
    } finally {
      setLoading(false);
    }
  }, [initialData]);

  const handleDataChange = useCallback(async (data: PaymentData) => {
    setExtractedData(data);
    try {
      const qrCode = await generateQRCode(data);
      setQrCodeData(qrCode);
    } catch (err) {
      console.error('Error generating QR code:', err);
    }
  }, []);

  const handlePositionChange = useCallback((position: { x: number; y: number } | null) => {
    setQrPosition(position);
  }, []);

  const handleGenerate = useCallback(async (qrText: string, qrSize: number) => {
    if (!pdfArrayBuffer || !qrPosition || !extractedData || !pdfFile) return;

    setIsGenerating(true);
    try {
      const modifiedPdf = await exportPDFWithQR(pdfArrayBuffer, extractedData, {
        position: qrPosition,
        qrText,
        qrSize
      });

      const blob = new Blob([modifiedPdf], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = pdfFile.name; // Use original filename
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate PDF');
    } finally {
      setIsGenerating(false);
    }
  }, [pdfArrayBuffer, qrPosition, extractedData, pdfFile]);

  return {
    loading,
    error,
    extractedData,
    pdfArrayBuffer,
    pdfFile,
    qrPosition,
    qrCodeData,
    isGenerating,
    handleFileUpload,
    handleDataChange,
    handlePositionChange,
    handleGenerate,
    setError,
    resetState
  };
}
