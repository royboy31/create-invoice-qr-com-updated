import React from 'react';
import { Upload, X } from 'lucide-react';

interface LogoUploaderProps {
  logo: string | null;
  onLogoChange: (logo: string | null) => void;
}

export default function LogoUploader({ logo, onLogoChange }: LogoUploaderProps) {
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please upload an image file');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      onLogoChange(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="mt-4">
      <label className="block text-sm font-medium text-[#c8c2bd] mb-2">
        QR Code Logo
      </label>
      <div className="flex items-center gap-4">
        {logo ? (
          <div className="relative">
            <img src={logo} alt="Logo" className="w-16 h-16 object-contain" />
            <button
              onClick={() => onLogoChange(null)}
              className="absolute -top-2 -right-2 p-1 bg-red-500 rounded-full text-white hover:bg-red-600"
            >
              <X size={14} />
            </button>
          </div>
        ) : (
          <label className="flex flex-col items-center justify-center w-16 h-16 border-2 border-dashed border-gray-800 rounded-lg cursor-pointer hover:border-indigo-500">
            <Upload size={24} className="text-[#c8c2bd]" />
            <input
              type="file"
              className="hidden"
              accept="image/*"
              onChange={handleFileChange}
            />
          </label>
        )}
      </div>
      <p className="mt-2 text-xs text-gray-500">
        Recommended: 100x100px PNG or SVG with transparency
      </p>
    </div>
  );
}
