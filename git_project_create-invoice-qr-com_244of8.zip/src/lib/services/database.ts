import { supabase } from '../supabase';
import { QRCodeType } from '../../types';

export async function createQRCode(type: QRCodeType, content: string) {
  try {
    const { data, error } = await supabase
      .from('qr_codes')
      .insert([{
        type,
        content,
        scans: 0
      }])
      .select()
      .single();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error creating QR code:', error);
    throw new Error('Failed to save QR code');
  }
}

export async function getQRCode(id: string) {
  const { data, error } = await supabase
    .from('qr_codes')
    .select('*')
    .eq('id', id)
    .single();

  if (error) throw error;
  return data;
}
