import React from 'react';
import { Minus, Plus } from 'lucide-react';

interface QRSizeControlProps {
  size: number;
  onSizeChange: (size: number) => void;
  min?: number;
  max?: number;
  step?: number;
}

export default function QRSizeControl({
  size,
  onSizeChange,
  min = 100,
  max = 400,
  step = 20
}: QRSizeControlProps) {
  return (
    <div className="flex items-center justify-between gap-4 w-full">
      <span className="text-sm text-[#c8c2bd]">QR Size:</span>
      <div className="flex items-center gap-2">
        <button
          onClick={() => onSizeChange(Math.max(min, size - step))}
          disabled={size <= min}
          className="p-1 text-[#c8c2bd] hover:bg-gray-800 rounded disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Minus className="w-4 h-4" />
        </button>
        <span className="text-sm text-[#c8c2bd] min-w-[3ch] text-center">
          {size}
        </span>
        <button
          onClick={() => onSizeChange(Math.min(max, size + step))}
          disabled={size >= max}
          className="p-1 text-[#c8c2bd] hover:bg-gray-800 rounded disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
