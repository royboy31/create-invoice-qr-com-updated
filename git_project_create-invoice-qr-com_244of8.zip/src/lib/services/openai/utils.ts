import { PaymentData } from '../../../types';

export function cleanInvoiceData(data: any): PaymentData {
  return {
    name: String(data.name || '').trim(),
    iban: String(data.iban || '').replace(/\s+/g, '').toUpperCase(),
    amount: typeof data.amount === 'number' ? data.amount : 
            typeof data.amount === 'string' ? parseFloat(data.amount.replace(/[^\d.,]/g, '').replace(',', '.')) : 0,
    currency: String(data.currency || 'EUR').toUpperCase(),
    reference: data.reference ? String(data.reference).trim() : undefined,
    info: data.reference ? `Invoice ${String(data.reference)}` : undefined,
    bic: data.bic ? String(data.bic).replace(/\s+/g, '').toUpperCase() : undefined
  };
}
