import React from 'react';
import { ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';

interface ZoomControlsProps {
  scale: number;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onReset: () => void;
}

export default function ZoomControls({
  scale,
  onZoomIn,
  onZoomOut,
  onReset
}: ZoomControlsProps) {
  return (
    <div className="flex items-center space-x-2">
      <button
        onClick={onZoomIn}
        className="p-2 hover:bg-gray-100 rounded-lg"
        title="Zoom In"
      >
        <ZoomIn className="w-5 h-5" />
      </button>
      <button
        onClick={onZoomOut}
        className="p-2 hover:bg-gray-100 rounded-lg"
        title="Zoom Out"
      >
        <ZoomOut className="w-5 h-5" />
      </button>
      <button
        onClick={onReset}
        className="p-2 hover:bg-gray-100 rounded-lg"
        title="Reset Zoom"
      >
        <RotateCcw className="w-5 h-5" />
      </button>
      <span className="text-sm text-gray-600 ml-2">
        {Math.round(scale * 100)}%
      </span>
    </div>
  );
}
