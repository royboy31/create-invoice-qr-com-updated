import React from 'react';
import { QrCode } from 'lucide-react';
import EditableText from './common/EditableText';

interface QRCodeDisplayProps {
  qrCodeData: string | null;
  error: string | null;
  text: string;
  onTextChange: (text: string) => void;
}

export default function QRCodeDisplay({ 
  qrCodeData, 
  error,
  text, 
  onTextChange
}: QRCodeDisplayProps) {
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>) => {
    if (!qrCodeData) return;

    e.dataTransfer.setData('application/qr-code', 'true');
    e.dataTransfer.effectAllowed = 'copy';

    const preview = document.createElement('div');
    preview.className = 'w-16 h-16 bg-white rounded-lg shadow-lg p-2';
    preview.innerHTML = '<div class="w-full h-full bg-indigo-600"></div>';
    document.body.appendChild(preview);
    e.dataTransfer.setDragImage(preview, 32, 32);
    
    setTimeout(() => document.body.removeChild(preview), 0);
  };

  return (
    <div className="flex flex-col items-center justify-center p-4 bg-black/30 rounded-lg">
      {qrCodeData ? (
        <div
          draggable
          onDragStart={handleDragStart}
          className="relative group cursor-move select-none"
        >
          <div className="bg-white rounded-lg shadow-lg p-3">
            <EditableText
              value={text}
              onChange={onTextChange}
              className="mb-2 text-sm font-medium text-gray-700"
            />
            <div className="relative">
              <img 
                src={qrCodeData} 
                alt="QR Code"
                className="w-48 h-48 rounded" // Reduced from w-64 h-64
                draggable={false}
              />
              <div className="absolute bottom-1 left-0 right-0 text-center">
                <span className="text-[8px] text-[#2c01ef] font-light">
                  Made by invoice-qr.com
                </span>
              </div>
            </div>
            <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-all duration-200 rounded-lg">
              <p className="text-white opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                Drag to PDF or click to place
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center text-gray-500">
          <QrCode size={48} className="mx-auto mb-4 opacity-50" /> {/* Reduced from size={64} */}
          <p>{error || 'Fill in the required payment details'}</p>
        </div>
      )}
    </div>
  );
}
