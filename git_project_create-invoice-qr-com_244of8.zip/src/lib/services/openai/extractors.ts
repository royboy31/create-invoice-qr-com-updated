import { openai } from './client';
import { PaymentData } from '../../../types';
import { cleanInvoiceData } from './utils';
import { handleOpenAIError } from './errors';
import { extractInvoiceDataWithRegex } from '../invoice/regex';
import { saveDebugResponse } from './debug';

export async function extractInvoiceData(text: string): Promise<PaymentData> {
  if (!text || typeof text !== 'string') {
    console.warn('Invalid text input, using regex extraction');
    return extractInvoiceDataWithRegex(String(text || ''));
  }

  // Check for API key
  if (!import.meta.env.VITE_OPENAI_API_KEY) {
    console.warn('OpenAI API key not found, using regex extraction');
    return extractInvoiceDataWithRegex(text);
  }

  try {
    const prompt = `Extract payment information from this invoice text. Be extremely precise and accurate.

IMPORTANT RULES:
1. The recipient name MUST BE the invoice EMITTER/SENDER (the one who issued the invoice)
2. Look for clear header sections or letterhead information to identify the emitter
3. Double check all extracted information for accuracy
4. Do not confuse client/billing information with the emitter's information
5. Look for IBAN or bank account information in a structured format
6. Amount should be the total/final amount including VAT if present

Return ONLY a JSON object with these fields:
- name: The invoice emitter's name (company or individual who issued the invoice)
- iban: IBAN number (if present)
- amount: numeric amount (if present)
- reference: invoice reference number (if present)
- currency: payment currency (if present, default to EUR)
- bic: BIC/SWIFT code (if present)

Invoice text:
${text}`;

    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{
        role: "user",
        content: prompt
      }],
      temperature: 0.1,
      max_tokens: 500,
      response_format: { type: "json_object" }
    });

    const content = response.choices[0].message?.content;
    
    // Save debug response
    saveDebugResponse({
      timestamp: new Date().toISOString(),
      prompt,
      response: content || '',
      success: !!content,
      error: content ? undefined : 'Empty response'
    });

    if (!content) {
      console.warn('Empty response from OpenAI, falling back to regex');
      return extractInvoiceDataWithRegex(text);
    }

    try {
      const result = JSON.parse(content);
      const cleanedData = cleanInvoiceData(result);
      
      // Validate extracted data
      if (!cleanedData.name || !cleanedData.iban || !cleanedData.amount) {
        console.warn('Incomplete data from OpenAI, falling back to regex');
        return extractInvoiceDataWithRegex(text);
      }
      
      return cleanedData;
    } catch (parseError) {
      console.warn('Failed to parse OpenAI response, falling back to regex:', parseError);
      return extractInvoiceDataWithRegex(text);
    }
  } catch (error) {
    console.warn('OpenAI API error, falling back to regex:', error);
    return extractInvoiceDataWithRegex(text);
  }
}
