import { WiFiData } from '../../types';

export function generateWiFiString(data: WiFiData): string {
  if (!data.ssid) throw new Error('Network name (SSID) is required');
  
  const hidden = data.hidden ? 'H:true' : '';
  const password = data.encryption !== 'nopass' ? `P:${data.password}` : '';
  
  return `WIFI:T:${data.encryption};S:${data.ssid};${password};${hidden};`;
}
