import QRCode from 'qrcode';
import { PaymentData } from '../types';
import { generatePaymentString } from './qrCodeGenerators';
import { validatePaymentData } from './validation/paymentValidation';

export async function generateQRCode(
  data: PaymentData,
  logo?: string | null
): Promise<string> {
  try {
    // Validate payment data
    const validationErrors = validatePaymentData(data.name, data.iban, data.amount);
    if (validationErrors.length > 0) {
      throw new Error(validationErrors[0]);
    }

    // Clean and validate data
    const cleanData: PaymentData = {
      name: data.name.trim(),
      iban: data.iban.replace(/\s+/g, '').toUpperCase(),
      amount: Number(data.amount),
      currency: data.currency || 'EUR',
      reference: data.reference?.trim(),
      bic: data.bic?.replace(/\s+/g, '').toUpperCase()
    };

    // Generate EPC QR code content
    const content = generatePaymentString(cleanData);
    
    // Generate QR code with error handling
    return await QRCode.toDataURL(content, {
      width: 400,
      margin: 2,
      errorCorrectionLevel: logo ? 'H' : 'M',
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
    });
  } catch (error) {
    console.error('Error generating QR code:', error);
    throw error instanceof Error ? error : new Error('Failed to generate QR code');
  }
}
