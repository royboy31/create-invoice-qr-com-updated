import { PaymentData } from '../../types';
import { extractTextFromPDF } from '../services/pdf';
import { extractInvoiceData as parseInvoiceData } from '../services/invoice';

export async function extractInvoiceData(pdfFile: File): Promise<PaymentData> {
  try {
    // First validate the file
    if (!pdfFile?.type?.includes('pdf')) {
      throw new Error('Please upload a valid PDF file');
    }

    // Extract text from PDF
    const text = await extractTextFromPDF(pdfFile);
    
    // Parse the extracted text to find invoice data
    const data = await parseInvoiceData(text);

    // Return with defaults for missing fields
    return {
      name: data.name || '',
      iban: data.iban || '',
      amount: data.amount || 0,
      currency: 'EUR',
      reference: data.reference,
      info: data.reference ? `Invoice ${data.reference}` : undefined,
      bic: undefined
    };
  } catch (error) {
    console.error('Invoice processing error:', error);
    // Return empty data for manual entry
    return {
      name: '',
      iban: '',
      amount: 0,
      currency: 'EUR'
    };
  }
}
