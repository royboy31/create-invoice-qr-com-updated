import { SearchResult } from '../types/search';

const searchableItems = [
  {
    id: 'url',
    title: 'Website URL QR Code',
    description: 'Create QR codes for websites and URLs',
    path: '/?type=url',
    keywords: ['website', 'url', 'link', 'web']
  },
  {
    id: 'vcard',
    title: 'Business Card QR Code',
    description: 'Generate QR codes for contact information',
    path: '/?type=vcard',
    keywords: ['contact', 'business card', 'vcard', 'phone']
  },
  {
    id: 'payment',
    title: 'Payment QR Code',
    description: 'Create QR codes for payment information',
    path: '/?type=payment',
    keywords: ['payment', 'money', 'transfer', 'bank']
  },
  {
    id: 'wifi',
    title: 'WiFi QR Code',
    description: 'Generate QR codes for WiFi networks',
    path: '/?type=wifi',
    keywords: ['wifi', 'network', 'internet', 'connection']
  },
  {
    id: 'invoice',
    title: 'Invoice Scanner',
    description: 'Scan and process invoices to generate payment QR codes',
    path: '/invoice',
    keywords: ['invoice', 'bill', 'payment', 'scan']
  }
];

export function searchItems(query: string): SearchResult[] {
  const normalizedQuery = query.toLowerCase().trim();
  
  if (!normalizedQuery) return [];

  return searchableItems.filter(item => {
    const matchTitle = item.title.toLowerCase().includes(normalizedQuery);
    const matchDescription = item.description.toLowerCase().includes(normalizedQuery);
    const matchKeywords = item.keywords.some(keyword => 
      keyword.toLowerCase().includes(normalizedQuery)
    );
    
    return matchTitle || matchDescription || matchKeywords;
  });
}
