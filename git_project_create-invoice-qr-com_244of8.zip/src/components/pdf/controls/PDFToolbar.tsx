import React from 'react';
import { Download, Upload } from 'lucide-react';
import ZoomControls from './ZoomControls';
import QRSizeControl from './QRSizeControl';

interface PDFToolbarProps {
  scale: number;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onResetZoom: () => void;
  onGenerate: () => void;
  isGenerating: boolean;
  hasQRCode: boolean;
  qrSize: number;
  onQRSizeChange: (size: number) => void;
  onUploadAnother: (event: React.ChangeEvent<HTMLInputElement>) => void;
}

export default function PDFToolbar({
  scale,
  onZoomIn,
  onZoomOut,
  onResetZoom,
  onGenerate,
  isGenerating,
  hasQRCode,
  qrSize,
  onQRSizeChange,
  onUploadAnother
}: PDFToolbarProps) {
  return (
    <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center justify-between">
      <div className="flex items-center gap-6">
        <ZoomControls
          scale={scale}
          onZoomIn={onZoomIn}
          onZoomOut={onZoomOut}
          onReset={onResetZoom}
        />
        {hasQRCode && (
          <QRSizeControl
            size={qrSize}
            onSizeChange={onQRSizeChange}
          />
        )}
      </div>
      
      <div className="flex items-center gap-2">
        <label className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded bg-indigo-600 text-white hover:bg-indigo-700 cursor-pointer transition-colors">
          <Upload className="w-3.5 h-3.5" />
          Upload new
          <input
            type="file"
            className="hidden"
            accept=".pdf"
            onChange={onUploadAnother}
          />
        </label>

        <button
          onClick={onGenerate}
          disabled={isGenerating || !hasQRCode}
          className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded transition-colors ${
            isGenerating || !hasQRCode
              ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
              : 'bg-indigo-600 hover:bg-indigo-700 text-white'
          }`}
        >
          <Download className="w-3.5 h-3.5" />
          Save PDF
        </button>
      </div>
    </div>
  );
}
