/*
  # Add Insert Policy for QR Codes

  1. Changes
    - Add policy to allow public insertion of QR codes
    
  2. Security
    - Allows anonymous users to create QR codes
    - Maintains existing read access
*/

-- Add policy to allow public insertion of QR codes
CREATE POLICY "Allow public to create QR codes"
  ON qr_codes
  FOR INSERT
  TO public
  WITH CHECK (true);
