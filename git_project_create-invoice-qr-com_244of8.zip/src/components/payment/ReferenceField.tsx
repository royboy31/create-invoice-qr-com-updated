import React, { useState, useEffect } from 'react';
import { Switch } from '../common/Switch';

interface ReferenceFieldProps {
  value: string;
  onChange: (value: string) => void;
  maxLength?: number;
  label: string;
}

export default function ReferenceField({
  value,
  onChange,
  maxLength = 35,
  label
}: ReferenceFieldProps) {
  const [isStructured, setIsStructured] = useState(false);
  const [inputValue, setInputValue] = useState('');

  // Auto-detect structured reference format on mount
  useEffect(() => {
    const isStructuredFormat = /^\+\+\+\d{3}\/\d{4}\/\d{5}\+\+\+$/.test(value);
    setIsStructured(isStructuredFormat);
    setInputValue(isStructuredFormat ? value.replace(/^\+\+\+|\+\+\+$/g, '') : value);
  }, []); // Only run on mount

  const formatStructuredValue = (input: string) => {
    // Remove all non-digits
    const digits = input.replace(/\D/g, '').slice(0, 12);
    let formatted = digits;

    if (digits.length > 3) {
      formatted = digits.slice(0, 3) + '/' + digits.slice(3);
    }
    if (digits.length > 7) {
      formatted = formatted.slice(0, 8) + '/' + digits.slice(7);
    }

    return formatted;
  };

  const handleStructuredChange = (newIsStructured: boolean) => {
    setIsStructured(newIsStructured);
    
    if (newIsStructured) {
      const formatted = formatStructuredValue(inputValue);
      setInputValue(formatted);
      
      if (/^\d{3}\/\d{4}\/\d{5}$/.test(formatted)) {
        onChange(`+++${formatted}+++`);
      } else {
        onChange(formatted);
      }
    } else {
      const unformatted = value.replace(/[^\d]/g, '');
      setInputValue(unformatted);
      onChange(unformatted);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let newValue = e.target.value;
    
    if (isStructured) {
      // Format the input value
      const formatted = formatStructuredValue(newValue);
      setInputValue(formatted);
      
      // Only add +++ when the format is complete
      if (/^\d{3}\/\d{4}\/\d{5}$/.test(formatted)) {
        onChange(`+++${formatted}+++`);
      } else {
        onChange(formatted);
      }
    } else {
      setInputValue(newValue);
      onChange(newValue);
    }
  };

  // Update input value when external value changes
  useEffect(() => {
    if (isStructured) {
      const cleanValue = value.replace(/^\+\+\+|\+\+\+$/g, '');
      setInputValue(cleanValue);
    } else {
      setInputValue(value);
    }
  }, [value, isStructured]);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <label className="text-xs text-[#c8c2bd]">{label}</label>
        <Switch
          checked={isStructured}
          onChange={handleStructuredChange}
          label="Structured"
        />
      </div>
      
      <div className="relative">
        <input
          type="text"
          value={inputValue}
          onChange={handleChange}
          maxLength={maxLength}
          placeholder={isStructured ? '123/1234/12345' : label}
          className="w-full px-4 py-2.5 text-sm bg-black/50 border border-gray-800 rounded-lg focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 text-[#c8c2bd]"
        />
      </div>
    </div>
  );
}
