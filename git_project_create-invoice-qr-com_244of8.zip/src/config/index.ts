interface Config {
  domain: string;
  isProduction: boolean;
}

const getConfig = (): Config => {
  const env = import.meta.env.MODE;
  const isProduction = env === 'production';

  return {
    domain: isProduction ? 'https://tulum.immo' : window.location.origin,
    isProduction
  };
};

export const config = getConfig();
