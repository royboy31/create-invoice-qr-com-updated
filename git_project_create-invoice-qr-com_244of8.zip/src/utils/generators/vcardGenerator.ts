import { VCardData } from '../../types';

export function generateVCardString(data: VCardData): string {
  const formatField = (key: string, value: string) => value ? `${key}:${value}\n` : '';
  
  return `BEGIN:VCARD
VERSION:3.0
${formatField('N', `${data.lastName};${data.firstName}`)}${formatField('FN', `${data.firstName} ${data.lastName}`)}${formatField('TEL;TYPE=CELL', data.mobile)}${formatField('TEL;TYPE=HOME', data.phone)}${formatField('TEL;TYPE=WORK', data.workPhone)}${formatField('TEL;TYPE=FAX', data.fax)}${formatField('EMAIL', data.email)}${formatField('ORG', data.company)}${formatField('TITLE', data.jobTitle)}${formatField('ADR', `;;${data.street};${data.city};${data.state};${data.zip};${data.country}`)}${formatField('URL', data.website)}END:VCARD`;
}
