/*
  # QR Code Tables Schema

  1. New Tables
    - `qr_codes`
      - `id` (uuid, primary key)
      - `type` (text)
      - `content` (text)
      - `scans` (integer)
      - `created_at` (timestamp)
      - `last_scan` (timestamp)
    - `scan_data`
      - `id` (uuid, primary key)
      - `qr_code_id` (uuid, foreign key)
      - `timestamp` (timestamp)
      - `user_agent` (text)
      - `platform` (text)
      - `language` (text)

  2. Security
    - Enable RLS on both tables
    - Add policies for public access to scan data
    - Add policies for authenticated users to manage their QR codes
*/

-- Create QR Codes table
CREATE TABLE IF NOT EXISTS qr_codes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL,
  content text NOT NULL,
  scans integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  last_scan timestamptz
);

-- Create Scan Data table
CREATE TABLE IF NOT EXISTS scan_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  qr_code_id uuid REFERENCES qr_codes(id) ON DELETE CASCADE,
  timestamp timestamptz DEFAULT now(),
  user_agent text,
  platform text,
  language text
);

-- Enable RLS
ALTER TABLE qr_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE scan_data ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public to scan QR codes"
  ON qr_codes
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow public to record scans"
  ON scan_data
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow public to view scan data"
  ON scan_data
  FOR SELECT
  TO public
  USING (true);
