export const validateUrl = (url: string): string => {
  if (!url) throw new Error('URL is required');
  try {
    const urlWithProtocol = url.startsWith('http') ? url : `https://${url}`;
    new URL(urlWithProtocol);
    return urlWithProtocol;
  } catch {
    throw new Error('Invalid URL format');
  }
};

export const validateText = (text: string): void => {
  if (!text) throw new Error('Text is required');
  if (text.length > 1000) throw new Error('Text is too long (max 1000 characters)');
};
