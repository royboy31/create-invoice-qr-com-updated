import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Move, Trash2 } from 'lucide-react';
import { PDF_CONSTANTS } from '../../lib/pdf/constants';

interface PDFEditorProps {
  qrPosition: { x: number; y: number } | null;
  onPositionChange: (position: { x: number; y: number } | null) => void;
  scale: number;
  qrCodeData: string | null;
  qrText?: string;
  qrSize?: number;
}

export default function PDFEditor({
  qrPosition,
  onPositionChange,
  scale,
  qrCodeData,
  qrText = 'Scan me in your bank app',
  qrSize = 100
}: PDFEditorProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [previewQRSize, setPreviewQRSize] = useState(qrSize);
  const dragRef = useRef<{ startX: number; startY: number; initialPos: { x: number; y: number } } | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Calculate the preview QR size based on PDF dimensions
  useEffect(() => {
    const calculatePreviewSize = () => {
      if (!containerRef.current) return;

      const containerWidth = containerRef.current.clientWidth;
      // PDF A4 width is 595 points (PDF_CONSTANTS.A4_WIDTH)
      // Calculate the ratio between preview width and PDF width
      const ratio = containerWidth / PDF_CONSTANTS.A4_WIDTH;
      // Scale QR size according to this ratio
      const scaledSize = qrSize * ratio;
      setPreviewQRSize(scaledSize);
    };

    calculatePreviewSize();
    window.addEventListener('resize', calculatePreviewSize);
    return () => window.removeEventListener('resize', calculatePreviewSize);
  }, [qrSize, scale]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if (!qrPosition) return;

    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);

    const container = e.currentTarget.parentElement;
    if (!container) return;

    const rect = container.getBoundingClientRect();
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialPos: { ...qrPosition }
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!dragRef.current) return;

      const dx = ((e.clientX - dragRef.current.startX) / (rect.width * scale)) * 100;
      const dy = ((e.clientY - dragRef.current.startY) / (rect.height * scale)) * 100;

      const newX = Math.max(5, Math.min(95, dragRef.current.initialPos.x + dx));
      const newY = Math.max(5, Math.min(95, dragRef.current.initialPos.y + dy));

      onPositionChange({ x: newX, y: newY });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      dragRef.current = null;
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  }, [qrPosition, onPositionChange, scale]);

  if (!qrPosition) return null;

  const fontSize = Math.max(8, Math.round(previewQRSize * 0.09));

  return (
    <div className="absolute inset-0 pointer-events-none" ref={containerRef}>
      <div
        className={`absolute ${isDragging ? 'opacity-50' : 'opacity-100'} transition-opacity duration-200 pointer-events-auto cursor-move`}
        style={{
          left: `${qrPosition.x}%`,
          top: `${qrPosition.y}%`,
          transform: `translate(-50%, -50%) scale(${1/scale})`,
          transformOrigin: 'center',
          willChange: 'transform'
        }}
        onMouseDown={handleMouseDown}
      >
        <div className="relative group">
          <div className="bg-white rounded-lg shadow-lg p-3">
            <div 
              className="text-center mb-1.5 font-medium text-gray-600"
              style={{ 
                width: `${previewQRSize}px`,
                maxWidth: `${previewQRSize}px`,
                fontSize: `${fontSize}px`,
                lineHeight: '1.2'
              }}
            >
              {qrText}
            </div>
            <img 
              src={qrCodeData || 'placeholder-qr-url'}
              alt="QR Code"
              style={{ 
                width: `${previewQRSize}px`, 
                height: `${previewQRSize}px` 
              }}
              className="rounded"
              draggable={false}
            />
            <div className="text-center mt-1">
              <span className="text-[8px] text-[#2c01ef] font-light">
                Made by invoice-qr.com
              </span>
            </div>
          </div>
          
          <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 hidden group-hover:flex items-center gap-2 bg-white rounded-t-lg shadow-lg px-2 py-1">
            <button
              className="p-1 hover:bg-gray-100 rounded"
              onClick={() => onPositionChange(null)}
              title="Remove QR Code"
            >
              <Trash2 className="w-4 h-4 text-red-500" />
            </button>
            <div className="flex items-center gap-1 text-gray-500">
              <Move className="w-4 h-4" />
              <span className="text-xs">Drag to move</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
