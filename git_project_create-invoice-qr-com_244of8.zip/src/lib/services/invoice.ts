import { PaymentData } from '../../types';

// Enhanced patterns for European invoices
const PATTERNS = {
  iban: [
    /(?:iban|account|konto)[\s:]*([A-Z]{2}\d{2}[A-Z0-9]{4}[0-9]{7}([A-Z0-9]?){0,16})/i,
    /([A-Z]{2}\d{2}[A-Z0-9]{4}[0-9]{7}([A-Z0-9]?){0,16})/i
  ],
  amount: [
    /(?:total|amount|sum|payable|due)[\s:]*(?:EUR|€)\s*(\d+(?:[.,]\d{2})?)/i,
    /(?:EUR|€)\s*(\d+(?:[.,]\d{2})?)/i,
    /(\d+(?:[.,]\d{2})?)\s*(?:EUR|€)/i
  ],
  name: [
    /(?:bill to|invoice to|recipient|payee|beneficiary)[\s:]*([^\n\r]+)/i,
    /(?:company|business|organization)[\s:]*name[\s:]*([^\n\r]+)/i,
    /(?:from|sender)[\s:]*([^\n\r]+)/i
  ],
  reference: [
    /(?:invoice|reference|ref|no\.|nummer)[\s:]*(?:number|#|nr\.?)?[\s:]*([A-Z0-9-]{3,})/i
  ]
};

function findMatch(text: string, patterns: RegExp[]): string {
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match?.[1]) {
      return match[1].trim();
    }
  }
  return '';
}

function cleanAmount(amount: string): number {
  if (!amount) return 0;
  const cleaned = amount.replace(/[^\d.,]/g, '').replace(',', '.');
  const parsed = parseFloat(cleaned);
  return isNaN(parsed) ? 0 : parsed;
}

function cleanIBAN(iban: string): string {
  if (!iban) return '';
  return iban.replace(/\s+/g, '').toUpperCase();
}

export async function extractInvoiceData(text: string): Promise<PaymentData> {
  try {
    // Clean up text
    const cleanText = text
      .replace(/\s+/g, ' ')
      .replace(/[^\x20-\x7E]/g, ' ')
      .trim();

    // Extract data using patterns
    const iban = cleanIBAN(findMatch(cleanText, PATTERNS.iban));
    const amount = cleanAmount(findMatch(cleanText, PATTERNS.amount));
    const name = findMatch(cleanText, PATTERNS.name);
    const reference = findMatch(cleanText, PATTERNS.reference);

    return {
      iban,
      name,
      amount,
      currency: 'EUR',
      reference: reference || undefined,
      info: reference ? `Invoice ${reference}` : undefined
    };
  } catch (error) {
    console.error('Data extraction error:', error);
    return {
      name: '',
      iban: '',
      amount: 0,
      currency: 'EUR'
    };
  }
}
