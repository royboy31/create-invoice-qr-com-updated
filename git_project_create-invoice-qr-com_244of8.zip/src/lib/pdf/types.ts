export interface PDFDimensions {
  width: number;
  height: number;
}

export interface PDFLoadOptions {
  scale?: number;
  maxWidth?: number;
}

export class PDFError extends Error {
  constructor(
    message: string,
    public code: string,
    public details?: any
  ) {
    super(message);
    this.name = 'PDFError';
  }
}

export interface PDFProcessingError {
  message: string;
  code: string;
  details?: any;
}
