import { useState, useCallback } from 'react';

export function useZoom(initialScale = 1) {
  const [scale, setScale] = useState(initialScale);

  const zoomIn = useCallback(() => 
    setScale(s => Math.min(s + 0.1, 2)), []
  );

  const zoomOut = useCallback(() => 
    setScale(s => Math.max(s - 0.1, 0.5)), []
  );

  const resetZoom = useCallback(() => 
    setScale(initialScale), [initialScale]
  );

  return {
    scale,
    zoomIn,
    zoomOut,
    resetZoom
  };
}
