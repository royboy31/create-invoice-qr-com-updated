import QRCode from 'qrcode';

interface QRCodeOptions {
  logo?: string | null;
  width?: number;
  margin?: number;
  errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H';
}

export async function generateQRCodeWithLogo(
  data: string,
  options: QRCodeOptions = {}
): Promise<string> {
  const {
    logo = null,
    width = 400,
    margin = 2,
    errorCorrectionLevel = 'H'
  } = options;

  // Generate base QR code
  const qrCodeDataUrl = await QRCode.toDataURL(data, {
    width,
    margin,
    errorCorrectionLevel,
    color: {
      dark: '#000000',
      light: '#ffffff',
    },
  });

  if (!logo) return qrCodeDataUrl;

  // Create canvas for combining QR code and logo
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas context not available');

  // Load QR code image
  const qrImage = await loadImage(qrCodeDataUrl);
  canvas.width = qrImage.width;
  canvas.height = qrImage.height;

  // Draw QR code
  ctx.drawImage(qrImage, 0, 0);

  // Load and draw logo
  const logoImage = await loadImage(logo);
  const logoSize = Math.floor(qrImage.width * 0.2); // Logo size: 20% of QR code
  const logoX = Math.floor((qrImage.width - logoSize) / 2);
  const logoY = Math.floor((qrImage.height - logoSize) / 2);

  // Draw white background for logo
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(logoX - 4, logoY - 4, logoSize + 8, logoSize + 8);

  // Draw logo
  ctx.drawImage(logoImage, logoX, logoY, logoSize, logoSize);

  return canvas.toDataURL('image/png');
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}
