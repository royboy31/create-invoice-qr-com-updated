import { PaymentData } from '../../types';

export function generatePaymentString(data: PaymentData): string {
  if (!data.iban || !data.amount) {
    throw new Error('IBAN and amount are required');
  }

  // Format amount to exactly 2 decimal places
  const formattedAmount = data.amount.toFixed(2);
  
  // Clean up input data
  const cleanIban = data.iban.replace(/\s+/g, '');
  const cleanName = data.name.trim().replace(/[\n\r]/g, ' ');
  const cleanReference = data.reference?.trim().replace(/[\n\r]/g, ' ') || '';
  
  // Build the EPC QR Code content
  const elements = [
    'BCD',                    // Service Tag
    '002',                    // Version
    '1',                      // Character Set (UTF-8)
    'SCT',                    // SEPA Credit Transfer
    '',                       // BIC (optional)
    cleanName,                // Recipient Name
    cleanIban,                // IBAN
    `${data.currency}${formattedAmount}`, // Currency + Amount
    '',                       // Purpose (not used)
    cleanReference,           // Reference
    ''                        // Additional Info
  ];

  return elements.join('\n');
}
