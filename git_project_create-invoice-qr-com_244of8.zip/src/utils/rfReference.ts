// Function to calculate RF reference check digits
function calculateCheckDigits(base: string): string {
  // Convert letters to numbers (A=10, B=11, etc)
  const converted = base.split('').map(char => {
    if (/[A-Z]/.test(char)) {
      return (char.charCodeAt(0) - 55).toString();
    }
    return char;
  }).join('');

  // Add "2715" to the end (RF becomes 2715)
  const withRF = `${converted}2715`;
  
  // Calculate MOD 97-10
  const mod = BigInt(withRF) % 97n;
  
  // Calculate check digits
  const checkDigits = (98 - Number(mod)).toString().padStart(2, '0');
  
  return checkDigits;
}

// Generate a random RF Creditor Reference
export function generateRFReference(): string {
  // Generate random base (16 digits)
  const base = Array.from({ length: 16 }, () => Math.floor(Math.random() * 10)).join('');
  
  // Calculate check digits
  const checkDigits = calculateCheckDigits(base);
  
  // Return full RF reference
  return `RF${checkDigits}${base}`;
}

// Validate RF Creditor Reference
export function validateRFReference(reference: string): boolean {
  // Basic format check
  if (!/^RF\d{2}[0-9A-Z]{1,21}$/.test(reference)) {
    return false;
  }

  // Extract parts
  const checkDigits = reference.substring(2, 4);
  const base = reference.substring(4);

  // Verify check digits
  return checkDigits === calculateCheckDigits(base);
}
