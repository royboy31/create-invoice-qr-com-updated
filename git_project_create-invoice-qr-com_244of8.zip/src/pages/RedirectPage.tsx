import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getQRCode } from '../lib/database/qrCode';
import { recordScan } from '../lib/database/scanData';

export default function RedirectPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [redirecting, setRedirecting] = useState(true);

  useEffect(() => {
    const redirect = async () => {
      if (!id) {
        navigate('/404');
        return;
      }

      try {
        // Start loading the QR code data immediately
        const qrCodePromise = getQRCode(id);
        
        // Create a minimal delay to allow browser to prepare for redirect
        const delayPromise = new Promise(resolve => setTimeout(resolve, 50));
        
        // Wait for both the QR code data and the minimal delay
        const [qrCode] = await Promise.all([qrCodePromise, delayPromise]);
        
        if (!qrCode) {
          navigate('/404');
          return;
        }

        // Record the scan in the background - don't wait for it
        recordScan(id).catch(console.error);

        const redirectUrl = qrCode.content;
        
        switch (qrCode.type) {
          case 'url': {
            const finalUrl = redirectUrl.startsWith('http') 
              ? redirectUrl 
              : `https://${redirectUrl}`;
            
            // Preload the destination
            const preloadLink = document.createElement('link');
            preloadLink.rel = 'preconnect';
            preloadLink.href = finalUrl;
            document.head.appendChild(preloadLink);

            // Immediate redirect
            window.location.replace(finalUrl);
            break;
          }
          
          case 'email':
          case 'sms':
          case 'wifi':
          case 'payment':
            window.location.replace(redirectUrl);
            break;
          
          case 'vcard': {
            const blob = new Blob([redirectUrl], { type: 'text/vcard' });
            const url = window.URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = 'contact.vcf';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            window.URL.revokeObjectURL(url);
            setRedirecting(false);
            break;
          }
          
          case 'text': {
            setError(null);
            setRedirecting(false);
            // Use a more performant way to update content
            const content = document.createElement('div');
            content.className = 'min-h-screen flex items-center justify-center bg-gray-50 p-4';
            content.innerHTML = `
              <div class="bg-white rounded-lg shadow-lg p-6 max-w-lg w-full">
                <pre class="whitespace-pre-wrap break-words text-gray-800">${
                  redirectUrl
                }</pre>
              </div>
            `;
            document.body.innerHTML = '';
            document.body.appendChild(content);
            break;
          }
          
          default:
            navigate('/404');
        }
      } catch (error) {
        console.error('Error processing QR code:', error);
        navigate('/404');
      }
    };

    redirect();
  }, [id, navigate]);

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Error</h1>
          <p className="text-gray-600">{error}</p>
        </div>
      </div>
    );
  }

  if (!redirecting) {
    return null;
  }

  // Use a minimal loading indicator that won't cause a flash
  return (
    <div className="fixed inset-0 bg-white bg-opacity-75 transition-opacity duration-300">
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
      </div>
    </div>
  );
}
