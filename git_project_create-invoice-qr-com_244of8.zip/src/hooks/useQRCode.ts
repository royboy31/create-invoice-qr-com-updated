import { useState, useEffect } from 'react';
import { PaymentData } from '../types';
import { generateQRCode } from '../utils/qrCode';
import { validatePaymentData } from '../utils/validation/paymentValidation';

export function useQRCode(data: PaymentData, logo: string | null = null) {
  const [qrCodeData, setQrCodeData] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    const generateCode = async () => {
      try {
        // Only generate if we have required fields
        if (!data.name || !data.iban || !data.amount) {
          setQrCodeData(null);
          return;
        }

        const qrCode = await generateQRCode(data, logo);
        if (mounted) {
          setQrCodeData(qrCode);
          setError(null);
        }
      } catch (err) {
        console.error('QR code generation error:', err);
        if (mounted) {
          setQrCodeData(null);
          setError(err instanceof Error ? err.message : 'Failed to generate QR code');
        }
      }
    };

    generateCode();

    return () => {
      mounted = false;
    };
  }, [data, logo]);

  return { qrCodeData, error };
}
