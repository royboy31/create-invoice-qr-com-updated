import React from 'react';
import { PaymentData } from '../../types';
import FormField from '../common/FormField';

interface PaymentFormProps {
  data: PaymentData;
  onChange: (data: PaymentData) => void;
}

export default function PaymentForm({ data, onChange }: PaymentFormProps) {
  const handleChange = (field: keyof PaymentData) => (value: string) => {
    if (field === 'amount') {
      onChange({ ...data, [field]: parseFloat(value) || 0 });
    } else {
      onChange({ ...data, [field]: value });
    }
  };

  return (
    <div className="space-y-6">
      <div className="relative">
        <input
          type="text"
          value={data.name}
          onChange={(e) => handleChange('name')(e.target.value)}
          placeholder="Enter recipient name"
          className="peer w-full px-4 py-2.5 text-sm bg-black/50 border border-gray-800 rounded-lg focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 placeholder-transparent text-[#c8c2bd]"
          id="recipient-name"
        />
        <label
          htmlFor="recipient-name"
          className="absolute z-10 left-2 -top-2.5 px-1 text-xs text-[#c8c2bd] transition-all 
                    bg-[#111] peer-placeholder-shown:text-sm peer-placeholder-shown:text-gray-500 
                    peer-placeholder-shown:top-2.5 peer-placeholder-shown:left-4 
                    peer-focus:-top-2.5 peer-focus:left-2 peer-focus:text-xs peer-focus:text-indigo-400"
        >
          Recipient Name
        </label>
      </div>

      <FormField
        label="IBAN"
        value={data.iban}
        onChange={handleChange('iban')}
        placeholder="e.g., DE89370400440532013000"
      />

      <div className="grid grid-cols-2 gap-4">
        <FormField
          label="Amount"
          value={data.amount.toString()}
          onChange={handleChange('amount')}
          type="number"
          placeholder="0.00"
        />
        <div className="relative mt-6">
          <input
            type="text"
            value="EUR"
            disabled
            className="w-full px-4 py-2.5 text-sm bg-black/50 border border-gray-800 rounded-lg text-[#c8c2bd] opacity-50"
          />
          <label className="absolute z-10 left-2 -top-3 px-2 text-xs text-[#c8c2bd] bg-[#111]">
            Currency
          </label>
        </div>
      </div>

      <FormField
        label="Payment Reference (Optional)"
        value={data.reference || ''}
        onChange={handleChange('reference')}
        placeholder="Max 35 characters"
      />
    </div>
  );
}
