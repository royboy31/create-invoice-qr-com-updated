import { supabase } from '../supabase';
import { QRCodeRecord } from './types';

export const createQRCode = async (type: string, content: string): Promise<QRCodeRecord> => {
  const { data, error } = await supabase
    .from('qr_codes')
    .insert([{
      type,
      content,
      scans: 0,
      created_at: new Date().toISOString(),
    }])
    .select()
    .single();

  if (error) {
    console.error('Error creating QR code:', error);
    throw error;
  }

  return data;
};

export const getQRCode = async (id: string): Promise<QRCodeRecord> => {
  const { data, error } = await supabase
    .from('qr_codes')
    .select(`
      *,
      scan_data (
        timestamp,
        user_agent,
        platform,
        language
      )
    `)
    .eq('id', id)
    .single();

  if (error) {
    console.error('Error fetching QR code:', error);
    throw error;
  }

  return data;
};
