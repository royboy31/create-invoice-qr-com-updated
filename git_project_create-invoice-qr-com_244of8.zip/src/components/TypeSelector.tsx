import React from 'react';
import { Link } from 'react-router-dom';
import { Link as LinkIcon, UserSquare2, Mail, MessageSquare, Type, Wifi, CreditCard, FileText } from 'lucide-react';
import { QRCodeType } from '../types';

interface TypeSelectorProps {
  qrType: QRCodeType;
  onTypeChange: (type: QRCodeType) => void;
}

const types = [
  { id: 'url', icon: LinkIcon, label: 'Website URL' },
  { id: 'vcard', icon: UserSquare2, label: 'Business Card' },
  { id: 'email', icon: Mail, label: 'Email' },
  { id: 'sms', icon: MessageSquare, label: 'SMS' },
  { id: 'text', icon: Type, label: 'Text' },
  { id: 'wifi', icon: Wifi, label: 'WiFi' },
  { id: 'payment', icon: CreditCard, label: 'Payment' },
] as const;

export default function TypeSelector({ qrType, onTypeChange }: TypeSelectorProps) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-8 gap-4 mb-8">
      {types.map(({ id, icon: Icon, label }) => (
        <button
          key={id}
          onClick={() => onTypeChange(id as QRCodeType)}
          className={`flex flex-col items-center gap-2 px-4 py-3 rounded-lg transition-all ${
            qrType === id
              ? 'bg-indigo-600 text-white'
              : 'bg-black/50 text-[#c8c2bd] hover:bg-black/70'
          }`}
        >
          <Icon size={24} />
          <span className="text-sm font-medium">{label}</span>
        </button>
      ))}
      
      <Link
        to="/invoice"
        className="flex flex-col items-center gap-2 px-4 py-3 rounded-lg transition-all bg-black/50 text-[#c8c2bd] hover:bg-black/70"
      >
        <FileText size={24} />
        <span className="text-sm font-medium">Invoice</span>
      </Link>
    </div>
  );
}
