import { PDFDocument } from 'pdf-lib';
import * as pdfjsLib from 'pdfjs-dist';
import { PDFError } from '../pdf/types';
import '../pdf/worker';

export async function extractTextFromPDF(pdfFile: File): Promise<string> {
  if (!pdfFile?.type?.includes('pdf')) {
    throw new PDFError('Please upload a valid PDF file', 'INVALID_FILE_TYPE');
  }

  let pdf = null;
  try {
    const arrayBuffer = await pdfFile.arrayBuffer();
    if (!arrayBuffer) {
      throw new PDFError('Failed to read PDF file', 'FILE_READ_ERROR');
    }

    const pdfDataArray = new Uint8Array(arrayBuffer);
    
    pdf = await pdfjsLib.getDocument({ 
      data: pdfDataArray,
      cMapUrl: 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.0.379/cmaps/',
      cMapPacked: true,
    }).promise;

    let fullText = '';
    const numPages = pdf.numPages;
    
    // Process all pages
    for (let i = 1; i <= numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      
      // Enhanced text extraction with better layout preservation
      const textItems = content.items
        .map((item: any) => ({
          text: item.str,
          x: Math.round(item.transform[4]),
          y: Math.round(item.transform[5]),
          fontSize: Math.round(Math.sqrt(item.transform[0] * item.transform[0] + item.transform[1] * item.transform[1]))
        }))
        .sort((a, b) => {
          // Group items by vertical position with some tolerance
          const yDiff = Math.abs(b.y - a.y);
          if (yDiff < 5) { // Items on roughly the same line
            return a.x - b.x; // Sort by x position
          }
          return b.y - a.y; // Sort by y position
        });

      // Improved text joining logic
      let currentY = textItems[0]?.y;
      let currentLine = '';
      
      textItems.forEach(item => {
        if (Math.abs(item.y - currentY) > 5) {
          // New line detected
          fullText += currentLine.trim() + '\n';
          currentLine = '';
          currentY = item.y;
        }
        // Add appropriate spacing based on x-position differences
        const needsSpace = currentLine.length > 0 && !currentLine.endsWith(' ');
        currentLine += (needsSpace ? ' ' : '') + item.text;
      });
      
      if (currentLine) {
        fullText += currentLine.trim() + '\n';
      }
    }

    const cleanText = fullText.trim();
    if (!cleanText) {
      throw new PDFError(
        'No readable text found in the PDF. The file might be scanned or contain only images.',
        'NO_TEXT_CONTENT'
      );
    }

    return cleanText;
  } catch (error) {
    if (error instanceof PDFError) throw error;
    
    console.error('PDF processing error:', error);
    throw new PDFError(
      'Failed to process the PDF. Please ensure the file is not corrupted.',
      'PDF_PROCESSING_ERROR',
      error
    );
  } finally {
    if (pdf?.destroy) {
      await pdf.destroy().catch(console.error);
    }
  }
}
