export type Language = 'en' | 'fr' | 'de' | 'nl';

export interface TranslationKeys {
  common: {
    upload: string;
    download: string;
    processing: string;
    dragAndDrop: string;
    error: string;
    success: string;
    next: string;
    back: string;
    cancel: string;
    save: string;
  };
  invoice: {
    title: string;
    subtitle: string;
    description: string;
    supportedBanks: string;
    supportedCountries: string;
    steps: {
      upload: {
        title: string;
        subtitle: string;
        description: string;
      };
      position: {
        title: string;
        subtitle: string;
        description: string;
      };
      verify: {
        title: string;
        subtitle: string;
        description: string;
      };
      export: {
        title: string;
        subtitle: string;
        description: string;
      };
    };
  };
  payment: {
    recipientName: string;
    iban: string;
    amount: string;
    reference: string;
    currency: string;
    qrText: string;
    qrSize: string;
  };
}

export type Translations = {
  [key in Language]: TranslationKeys;
};
