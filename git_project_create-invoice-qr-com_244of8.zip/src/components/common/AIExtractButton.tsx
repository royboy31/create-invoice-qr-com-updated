import React from 'react';
import { Sparkles } from 'lucide-react';

interface AIExtractButtonProps {
  onClick: () => void;
  loading?: boolean;
  disabled?: boolean;
}

export default function AIExtractButton({ onClick, loading, disabled }: AIExtractButtonProps) {
  return (
    <button
      onClick={onClick}
      disabled={loading || disabled}
      className={`w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors
        ${loading || disabled
          ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
          : 'bg-gradient-to-r from-indigo-500 to-purple-500 text-white hover:from-indigo-600 hover:to-purple-600'
        }`}
    >
      <Sparkles className="w-4 h-4" />
      {loading ? 'Analyzing Invoice...' : 'Extract Data with AI'}
    </button>
  );
}
