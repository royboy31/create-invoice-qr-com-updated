// Utility functions for Belgian structured reference format

export function generateBelgianReference(): string {
  // Generate 10 random digits
  const digits = Array.from({ length: 10 }, () => Math.floor(Math.random() * 10));
  
  // Calculate check digits (last 2 digits)
  const number = parseInt(digits.join(''), 10);
  const checksum = (98 - (number % 97)) % 97;
  const checksumStr = checksum.toString().padStart(2, '0');
  
  // Format as +++XXX/XXXX/XXXXX+++
  const fullNumber = digits.join('') + checksumStr;
  const part1 = fullNumber.slice(0, 3);
  const part2 = fullNumber.slice(3, 7);
  const part3 = fullNumber.slice(7);
  
  return `+++${part1}/${part2}/${part3}+++`;
}

export function validateBelgianReference(reference: string): boolean {
  // Remove formatting
  const digits = reference.replace(/[^0-9]/g, '');
  if (digits.length !== 12) return false;

  // Check modulo 97
  const number = parseInt(digits.slice(0, 10), 10);
  const checksum = parseInt(digits.slice(10), 10);
  return checksum === ((98 - (number % 97)) % 97);
}

export function formatBelgianReference(input: string): string {
  // Remove all non-digits
  const digits = input.replace(/\D/g, '').slice(0, 12);
  
  if (digits.length === 0) return '';
  
  if (digits.length <= 3) {
    return `+++${digits}`;
  } else if (digits.length <= 7) {
    return `+++${digits.slice(0, 3)}/${digits.slice(3)}`;
  } else {
    const formatted = `+++${digits.slice(0, 3)}/${digits.slice(3, 7)}/${digits.slice(7, 12)}${digits.length === 12 ? '+++' : ''}`;
    return formatted;
  }
}
