import React from 'react';

interface AmountFieldProps {
  value: number;
  onChange: (value: string) => void;
  label: string;
}

export default function AmountField({ value, onChange, label }: AmountFieldProps) {
  return (
    <div className="relative">
      <input
        type="number"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="0.00"
        className="peer w-full px-4 py-2.5 text-sm bg-black/50 border border-gray-800 rounded-lg focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 placeholder-transparent text-[#c8c2bd]"
        id="amount-field"
      />
      <label
        htmlFor="amount-field"
        className="absolute z-10 left-2 -top-2.5 px-1 text-xs text-[#c8c2bd] transition-all 
                  bg-[#111] peer-placeholder-shown:text-sm peer-placeholder-shown:text-gray-500 
                  peer-placeholder-shown:top-2.5 peer-placeholder-shown:left-4 
                  peer-focus:-top-2.5 peer-focus:left-2 peer-focus:text-xs peer-focus:text-indigo-400"
      >
        {label}
      </label>
    </div>
  );
}
