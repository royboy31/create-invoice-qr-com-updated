import { PDFDocument, rgb } from 'pdf-lib';
import { generateQRCode } from '../utils/qrCode';
import { PaymentData } from '../../types';
import { PDF_CONSTANTS } from './constants';

interface ExportOptions {
  position: { x: number; y: number };
  qrText: string;
  qrSize: number;
}

export async function exportPDFWithQR(
  originalPdf: ArrayBuffer,
  paymentData: PaymentData,
  options: ExportOptions
): Promise<Uint8Array> {
  try {
    // Load the PDF document
    const pdfDoc = await PDFDocument.load(originalPdf);
    const page = pdfDoc.getPages()[0];
    const { width, height } = page.getSize();

    // Generate QR code
    const qrCodeDataUrl = await generateQRCode(paymentData);
    const qrCodeImageData = qrCodeDataUrl.replace('data:image/png;base64,', '');
    const qrCodeImage = await pdfDoc.embedPng(qrCodeImageData);

    // Calculate positions (convert from percentage to points)
    const qrX = (options.position.x / 100) * width - (options.qrSize / 2);
    const qrY = height - ((options.position.y / 100) * height) - (options.qrSize / 2);

    // Add white background for better visibility
    page.drawRectangle({
      x: qrX - 4,
      y: qrY - 4,
      width: options.qrSize + 8,
      height: options.qrSize + 30,
      color: rgb(1, 1, 1),
      opacity: 1
    });

    // Draw QR code
    page.drawImage(qrCodeImage, {
      x: qrX,
      y: qrY,
      width: options.qrSize,
      height: options.qrSize
    });

    // Add text above QR code
    const font = await pdfDoc.embedFont('Helvetica');
    const fontSize = Math.max(8, Math.round(options.qrSize * 0.09));
    const textWidth = font.widthOfTextAtSize(options.qrText, fontSize);
    
    page.drawText(options.qrText, {
      x: qrX + (options.qrSize - textWidth) / 2,
      y: qrY + options.qrSize + 8,
      size: fontSize,
      font,
      color: rgb(0, 0, 0)
    });

    // Add attribution
    const attribution = 'Made by invoice-qr.com';
    const attributionSize = 8;
    const attributionWidth = font.widthOfTextAtSize(attribution, attributionSize);
    
    page.drawText(attribution, {
      x: qrX + (options.qrSize - attributionWidth) / 2,
      y: qrY - 12,
      size: attributionSize,
      font,
      color: rgb(0.17, 0.004, 0.94)
    });

    return await pdfDoc.save();
  } catch (error) {
    console.error('Error exporting PDF:', error);
    throw new Error('Failed to generate PDF with QR code');
  }
}
