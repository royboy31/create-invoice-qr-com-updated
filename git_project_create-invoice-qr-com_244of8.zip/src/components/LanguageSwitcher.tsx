import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import type { Language } from '../i18n/types';

const languages: { code: Language; label: string }[] = [
  { code: 'en', label: 'EN' },
  { code: 'fr', label: 'FR' },
  { code: 'de', label: 'DE' },
  { code: 'nl', label: 'NL' }
];

export default function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="flex items-center gap-1">
      {languages.map(({ code, label }) => (
        <button
          key={code}
          onClick={() => setLanguage(code)}
          className={`px-2 py-1 text-sm rounded transition-colors ${
            language === code
              ? 'bg-indigo-600 text-white'
              : 'text-[#c8c2bd] hover:text-white hover:bg-gray-800'
          }`}
        >
          {label}
        </button>
      ))}
    </div>
  );
}
