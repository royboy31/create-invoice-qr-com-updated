import OpenAI from 'openai';
import { PaymentData } from '../../types';

const openai = new OpenAI({
  apiKey: import.meta.env.VITE_OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

export async function extractInvoiceDataWithGPT(text: string): Promise<PaymentData> {
  try {
    const prompt = `Extract payment information from this invoice text. Return a JSON object with these fields:
      - name: recipient/company name
      - iban: IBAN number (if present)
      - amount: numeric amount (if present)
      - reference: invoice reference number (if present)
      - currency: payment currency (if present, default to EUR)

      Invoice text:
      ${text}`;

    const response = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{
        role: "user",
        content: prompt
      }],
      temperature: 0.1,
    });

    const content = response.choices[0].message?.content;
    if (!content) {
      throw new Error('No response from OpenAI');
    }

    const result = JSON.parse(content);
    return {
      name: result.name?.trim() || '',
      iban: result.iban?.replace(/\s+/g, '').toUpperCase() || '',
      amount: typeof result.amount === 'number' ? result.amount : 
              typeof result.amount === 'string' ? parseFloat(result.amount.replace(/[^\d.,]/g, '').replace(',', '.')) : 0,
      currency: result.currency?.toUpperCase() || 'EUR',
      reference: result.reference?.trim(),
      info: result.reference ? `Invoice ${result.reference}` : undefined
    };
  } catch (error) {
    console.error('OpenAI extraction error:', error);
    throw new Error('Failed to extract data using AI');
  }
}
