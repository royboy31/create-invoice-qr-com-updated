export interface QRCodeRecord {
  id: string;
  type: string;
  content: string;
  scans: number;
  created_at: string;
  last_scan?: string;
  scan_data?: ScanRecord[];
}

export interface ScanRecord {
  id: string;
  qr_code_id: string;
  timestamp: string;
  user_agent?: string;
  platform?: string;
  language?: string;
}
