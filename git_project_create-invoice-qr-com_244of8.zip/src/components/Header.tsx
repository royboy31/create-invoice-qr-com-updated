import React from 'react';
import { QrCode } from 'lucide-react';
import { Link } from 'react-router-dom';
import LanguageSwitcher from './LanguageSwitcher';
import { useLanguage } from '../contexts/LanguageContext';

export default function Header() {
  const { t } = useLanguage();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black/30 backdrop-blur-md border-b border-gray-800">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
        <div className="flex items-center justify-between h-20">
          <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <QrCode className="h-8 w-8 text-[#fffaf6]" />
            <div className="flex flex-col">
              <span className="text-lg font-medium text-[#fffaf6]">QR Invoice</span>
              <span className="text-xs text-[#86868b]">{t('invoice.subtitle')}</span>
            </div>
          </Link>

          <LanguageSwitcher />
        </div>
      </div>
    </header>
  );
}
