import React, { memo } from 'react';

interface FormFieldProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  placeholder?: string;
}

function FormField({ 
  label, 
  value, 
  onChange, 
  type = 'text', 
  placeholder = '' 
}: FormFieldProps) {
  return (
    <div className="relative">
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="peer w-full px-4 py-2.5 text-sm bg-black/50 border border-gray-800 rounded-lg focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 placeholder-transparent text-[#c8c2bd]"
        id={`field-${label.toLowerCase().replace(/\s+/g, '-')}`}
      />
      <label
        htmlFor={`field-${label.toLowerCase().replace(/\s+/g, '-')}`}
        className="absolute z-10 left-2 -top-2.5 px-1 text-xs text-[#c8c2bd] transition-all 
                  bg-[#111] peer-placeholder-shown:text-sm peer-placeholder-shown:text-gray-500 
                  peer-placeholder-shown:top-2.5 peer-placeholder-shown:left-4 
                  peer-focus:-top-2.5 peer-focus:left-2 peer-focus:text-xs peer-focus:text-indigo-400"
      >
        {label}
      </label>
    </div>
  );
}

export default memo(FormField);
