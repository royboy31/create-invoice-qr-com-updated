import { useState, useCallback } from 'react';
import { searchItems } from '../utils/search';
import { SearchResult } from '../types/search';

export function useSearch() {
  const [results, setResults] = useState<SearchResult[]>([]);

  const search = useCallback((query: string) => {
    if (!query.trim()) {
      setResults([]);
      return;
    }
    
    const searchResults = searchItems(query);
    setResults(searchResults);
  }, []);

  return { results, search };
}
