import React from 'react';
import { FileText, Target, CheckCircle, Download } from 'lucide-react';
import PDFPreview from './PDFPreview';
import PaymentDetailsSidebar from './PaymentDetailsSidebar';
import PDFUploader from './pdf/PDFUploader';
import { useInvoiceProcessor } from '../hooks/useInvoiceProcessor';
import { getDefaultPaymentData } from '../lib/utils/defaults';
import { useLanguage } from '../contexts/LanguageContext';

export default function InvoiceProcessor() {
  const { t } = useLanguage();
  const {
    loading,
    error,
    extractedData,
    pdfArrayBuffer,
    qrPosition,
    qrCodeData,
    isGenerating,
    handleFileUpload,
    handleDataChange,
    handlePositionChange,
    handleGenerate,
    setError,
    resetState
  } = useInvoiceProcessor(getDefaultPaymentData());

  const [qrText, setQrText] = React.useState('Scan me in your bank app');
  const [qrSize, setQrSize] = React.useState(100);

  return (
    <div className="flex flex-col h-full">
      {!pdfArrayBuffer ? (
        <div className="space-y-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-[#fffaf6] mb-2">
              {t('invoice.title')}
            </h1>
            <h2 className="text-2xl font-medium text-[#c8c2bd] mb-4">
              {t('invoice.subtitle')}
            </h2>
            <p className="text-[#86868b] max-w-2xl mx-auto mb-8">
              {t('invoice.description')}
            </p>
          </div>

          <PDFUploader
            onUpload={handleFileUpload}
            loading={loading}
            error={error}
            onErrorDismiss={() => setError(null)}
          />
          
          <div className="text-center">
            <p className="text-sm font-medium text-[#86868b] mb-2">
              {t('invoice.supportedBanks')}
            </p>
            <p className="text-[#c8c2bd]">
              {t('invoice.supportedCountries')}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12">
            <div className="bg-[#1a1a1a] rounded-lg p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-indigo-600/20 p-3 rounded-lg">
                  <FileText className="w-6 h-6 text-indigo-500" />
                </div>
                <div>
                  <h3 className="text-[#c8c2bd] font-medium">{t('invoice.steps.upload.title')}</h3>
                  <p className="text-[#86868b]">{t('invoice.steps.upload.subtitle')}</p>
                </div>
              </div>
              <p className="text-[#86868b] text-sm">
                {t('invoice.steps.upload.description')}
              </p>
            </div>

            <div className="bg-[#1a1a1a] rounded-lg p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-blue-600/20 p-3 rounded-lg">
                  <Target className="w-6 h-6 text-blue-500" />
                </div>
                <div>
                  <h3 className="text-[#c8c2bd] font-medium">{t('invoice.steps.position.title')}</h3>
                  <p className="text-[#86868b]">{t('invoice.steps.position.subtitle')}</p>
                </div>
              </div>
              <p className="text-[#86868b] text-sm">
                {t('invoice.steps.position.description')}
              </p>
            </div>

            <div className="bg-[#1a1a1a] rounded-lg p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-green-600/20 p-3 rounded-lg">
                  <CheckCircle className="w-6 h-6 text-green-500" />
                </div>
                <div>
                  <h3 className="text-[#c8c2bd] font-medium">{t('invoice.steps.verify.title')}</h3>
                  <p className="text-[#86868b]">{t('invoice.steps.verify.subtitle')}</p>
                </div>
              </div>
              <p className="text-[#86868b] text-sm">
                {t('invoice.steps.verify.description')}
              </p>
            </div>

            <div className="bg-[#1a1a1a] rounded-lg p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="bg-purple-600/20 p-3 rounded-lg">
                  <Download className="w-6 h-6 text-purple-500" />
                </div>
                <div>
                  <h3 className="text-[#c8c2bd] font-medium">{t('invoice.steps.export.title')}</h3>
                  <p className="text-[#86868b]">{t('invoice.steps.export.subtitle')}</p>
                </div>
              </div>
              <p className="text-[#86868b] text-sm">
                {t('invoice.steps.export.description')}
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex h-full relative">
          <div className="flex-1 min-h-0">
            <PDFPreview
              pdfArrayBuffer={pdfArrayBuffer}
              qrPosition={qrPosition}
              onPositionChange={handlePositionChange}
              onGenerate={handleGenerate}
              isGenerating={isGenerating}
              qrCodeData={qrCodeData}
              qrText={qrText}
              qrSize={qrSize}
              onQRSizeChange={setQrSize}
              onClose={resetState}
              onUploadAnother={handleFileUpload}
            />
          </div>

          {extractedData && (
            <div className="w-96 bg-[#111] border-l border-gray-800">
              <PaymentDetailsSidebar
                data={extractedData}
                onChange={handleDataChange}
                qrText={qrText}
                onQRTextChange={setQrText}
                qrSize={qrSize}
                onQRSizeChange={setQrSize}
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
