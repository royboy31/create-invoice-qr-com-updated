import React from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { PaymentData } from '../types';
import QRCodeDisplay from './QRCodeDisplay';
import FormField from './common/FormField';
import ReferenceField from './payment/ReferenceField';
import AmountField from './payment/AmountField';
import CurrencySelect from './payment/CurrencySelect';
import { useLanguage } from '../contexts/LanguageContext';
import { useQRCode } from '../hooks/useQRCode';

interface PaymentDetailsSidebarProps {
  data: PaymentData;
  onChange: (data: PaymentData) => void;
  qrText: string;
  onQRTextChange: (text: string) => void;
  qrSize: number;
  onQRSizeChange: (size: number) => void;
}

export default function PaymentDetailsSidebar({
  data,
  onChange,
  qrText,
  onQRTextChange,
  qrSize,
  onQRSizeChange
}: PaymentDetailsSidebarProps) {
  const { t } = useLanguage();
  const { qrCodeData, error } = useQRCode(data);

  const handleChange = (field: keyof PaymentData) => (value: string) => {
    if (field === 'amount') {
      onChange({ ...data, [field]: parseFloat(value) || 0 });
    } else {
      onChange({ ...data, [field]: value });
    }
  };

  return (
    <div className="h-full flex flex-col bg-[#111] overflow-hidden">
      <div className="flex items-center justify-between p-6 border-b border-gray-800">
        <h3 className="text-lg font-medium text-[#c8c2bd]">
          {t('invoice.steps.verify.subtitle')}
        </h3>
      </div>

      <div className="flex-1 overflow-auto p-6 space-y-6">
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded">
          <div className="flex items-start">
            <AlertTriangle className="h-5 w-5 text-yellow-400 mt-0.5" />
            <div className="ml-3">
              <p className="text-sm text-yellow-700">
                {t('invoice.verifyWarning')}
              </p>
            </div>
          </div>
        </div>

        <div className="mb-8">
          <QRCodeDisplay 
            qrCodeData={qrCodeData} 
            error={error}
            text={qrText}
            onTextChange={onQRTextChange}
          />
        </div>

        <div className="space-y-6">
          <FormField
            label={t('payment.qrText')}
            value={qrText}
            onChange={onQRTextChange}
            placeholder={t('payment.qrText')}
          />

          <FormField
            label={t('payment.recipientName')}
            value={data.name}
            onChange={handleChange('name')}
            placeholder={t('payment.recipientName')}
          />

          <FormField
            label="IBAN"
            value={data.iban}
            onChange={handleChange('iban')}
            placeholder="BE68539007547034"
          />

          <FormField
            label="BIC/SWIFT"
            value={data.bic || ''}
            onChange={handleChange('bic')}
            placeholder="GEBABEBB"
          />

          <div className="grid grid-cols-2 gap-4">
            <AmountField
              value={data.amount}
              onChange={handleChange('amount')}
              label={t('payment.amount')}
            />
            <CurrencySelect
              value={data.currency}
              onChange={handleChange('currency')}
              label={t('payment.currency')}
            />
          </div>

          <ReferenceField
            value={data.reference || ''}
            onChange={handleChange('reference')}
            maxLength={35}
            label={t('payment.reference')}
          />
        </div>
      </div>
    </div>
  );
}
