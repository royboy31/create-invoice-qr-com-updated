import React from 'react';
import QRCodeDisplay from '../QRCodeDisplay';

interface QRPreviewSectionProps {
  qrCodeData: string | null;
  qrText: string;
  logo: string | null;
  onLogoChange: (logo: string | null) => void;
  className?: string;
}

export function QRPreviewSection({
  qrCodeData,
  qrText,
  logo,
  onLogoChange,
  className = ''
}: QRPreviewSectionProps) {
  return (
    <div className={className}>
      <QRCodeDisplay
        qrCodeData={qrCodeData}
        text={qrText}
        onTextChange={() => {}}
        logo={logo}
        onLogoChange={onLogoChange}
      />
    </div>
  );
}
