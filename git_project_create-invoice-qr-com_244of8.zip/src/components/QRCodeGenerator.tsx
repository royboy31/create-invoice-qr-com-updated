import React, { useState } from 'react';
import { QrCode } from 'lucide-react';
import TypeSelector from './TypeSelector';
import { QRCodeType, QRCodeParams } from '../types';
import { QRFormSection } from './sections/QRFormSection';
import { QRPreviewSection } from './sections/QRPreviewSection';
import { generateQRCode } from '../utils/qrCode';

export default function QRCodeGenerator() {
  const [qrType, setQrType] = useState<QRCodeType>('url');
  const [qrCodeData, setQrCodeData] = useState<string | null>(null);
  const [qrText, setQrText] = useState('Scan me in your bank app');
  const [error, setError] = useState('');
  const [formData, setFormData] = useState<QRCodeParams>({
    url: '',
    vcardData: {
      firstName: '', lastName: '', mobile: '', phone: '', workPhone: '', fax: '',
      email: '', company: '', jobTitle: '', street: '', city: '', zip: '',
      state: '', country: '', website: ''
    },
    emailData: { email: '', subject: '', body: '' },
    smsData: { phone: '', message: '' },
    text: '',
    wifiData: { ssid: '', password: '', encryption: 'WPA', hidden: false },
    paymentData: { name: '', iban: '', amount: 0, currency: 'EUR' }
  });

  const handleTypeChange = (type: QRCodeType) => {
    setQrType(type);
    setQrCodeData(null);
    setError('');
    // Reset QR text to default for payment type
    if (type === 'payment') {
      setQrText('Scan me in your bank app');
    }
  };

  const handleFormDataChange = (newData: Partial<QRCodeParams>) => {
    setFormData(prev => ({ ...prev, ...newData }));
  };

  const handleGenerate = async () => {
    try {
      const qrCode = await generateQRCode(qrType, formData);
      setQrCodeData(qrCode);
      setError('');
    } catch (err) {
      console.error('QR code generation error:', err);
      setError(err instanceof Error ? err.message : 'Failed to generate QR code');
    }
  };

  return (
    <div className="relative min-h-screen">
      <div className="bg-glow"></div>
      
      <div className="relative z-10 max-w-6xl mx-auto px-6 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl mb-6">
            <span className="block text-[#c8c2bd] font-light mb-2">
              Create Professional
            </span>
            <span className="glow-text" data-text="QR Codes">
              QR Codes
            </span>
          </h1>
          <p className="text-[#86868b] text-lg max-w-2xl mx-auto">
            Generate QR codes for websites, business cards, payments and more with our
            <span className="text-[#e7dfd6] font-medium"> advanced QR code generator</span>
          </p>
        </div>

        <div className="bg-[#111] bg-opacity-50 backdrop-blur-lg rounded-xl border border-gray-800">
          <div className="p-8">
            <TypeSelector qrType={qrType} onTypeChange={handleTypeChange} />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mt-12">
              <QRFormSection
                qrType={qrType}
                formData={formData}
                onFormDataChange={handleFormDataChange}
                error={error}
                onGenerate={handleGenerate}
                qrText={qrText}
                onQRTextChange={setQrText}
              />

              <QRPreviewSection
                qrCodeData={qrCodeData}
                qrText={qrText}
                onQRTextChange={setQrText}
                className="lg:border-l lg:border-gray-800 lg:pl-16"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
