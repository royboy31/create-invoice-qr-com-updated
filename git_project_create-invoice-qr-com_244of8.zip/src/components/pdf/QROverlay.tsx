import React from 'react';
import { QrCode } from 'lucide-react';

interface QROverlayProps {
  position: { x: number, y: number };
  scale: number;
  onDragStart: () => void;
  onDragEnd: () => void;
  onDrag: (x: number, y: number) => void;
}

export default function QROverlay({ 
  position, 
  scale,
  onDragStart,
  onDragEnd,
  onDrag 
}: QROverlayProps) {
  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    onDragStart();

    const startX = e.clientX;
    const startY = e.clientY;
    const startPosX = position.x;
    const startPosY = position.y;

    const handleMouseMove = (e: MouseEvent) => {
      const dx = (e.clientX - startX) / scale;
      const dy = (e.clientY - startY) / scale;
      onDrag(startPosX + dx, startPosY + dy);
    };

    const handleMouseUp = () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      onDragEnd();
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  return (
    <div
      className="absolute cursor-move"
      style={{
        transform: `translate(${position.x * scale}px, ${position.y * scale}px)`,
        width: '100px',
        height: '100px',
        marginLeft: '-50px',
        marginTop: '-50px'
      }}
      onMouseDown={handleMouseDown}
    >
      <div className="flex items-center justify-center w-full h-full">
        <QrCode className="w-full h-full text-indigo-600 opacity-75" />
      </div>
    </div>
  );
}
