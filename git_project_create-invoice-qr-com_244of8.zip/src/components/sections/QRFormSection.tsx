import React from 'react';
import { QrCode } from 'lucide-react';
import { QRCodeType, QRCodeParams } from '../../types';
import URLForm from '../URLForm';
import VCardForm from '../VCardForm';
import EmailForm from '../forms/EmailForm';
import SMSForm from '../forms/SMSForm';
import TextField from '../forms/TextField';
import WiFiForm from '../forms/WiFiForm';
import PaymentForm from '../forms/PaymentForm';
import FormField from '../common/FormField';

interface QRFormSectionProps {
  qrType: QRCodeType;
  formData: QRCodeParams;
  onFormDataChange: (data: Partial<QRCodeParams>) => void;
  error: string;
  onGenerate: () => void;
  qrText: string;
  onQRTextChange: (text: string) => void;
}

export function QRFormSection({
  qrType,
  formData,
  onFormDataChange,
  error,
  onGenerate,
  qrText,
  onQRTextChange
}: QRFormSectionProps) {
  const renderForm = () => {
    switch (qrType) {
      case 'url':
        return (
          <URLForm 
            url={formData.url || ''} 
            onUrlChange={url => onFormDataChange({ url })} 
          />
        );
      case 'vcard':
        return (
          <VCardForm 
            data={formData.vcardData!} 
            onChange={vcardData => onFormDataChange({ vcardData })} 
          />
        );
      case 'email':
        return (
          <EmailForm 
            data={formData.emailData!} 
            onChange={emailData => onFormDataChange({ emailData })} 
          />
        );
      case 'sms':
        return (
          <SMSForm 
            data={formData.smsData!} 
            onChange={smsData => onFormDataChange({ smsData })} 
          />
        );
      case 'text':
        return (
          <TextField 
            text={formData.text || ''} 
            onChange={text => onFormDataChange({ text })} 
          />
        );
      case 'wifi':
        return (
          <WiFiForm 
            data={formData.wifiData!} 
            onChange={wifiData => onFormDataChange({ wifiData })} 
          />
        );
      case 'payment':
        return (
          <>
            <FormField
              label="QR Code Text"
              value={qrText}
              onChange={onQRTextChange}
              placeholder="Text displayed above QR code"
            />
            <PaymentForm 
              data={formData.paymentData!} 
              onChange={paymentData => onFormDataChange({ paymentData })}
            />
          </>
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-8">
      {renderForm()}

      {error && (
        <p className="mt-2 text-red-600 text-sm">{error}</p>
      )}

      <button
        onClick={onGenerate}
        className="w-full py-4 px-6 flex items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white transition-colors duration-200 uppercase tracking-wider text-sm font-medium"
      >
        <QrCode className="h-5 w-5" />
        Generate QR Code
      </button>
    </div>
  );
}
