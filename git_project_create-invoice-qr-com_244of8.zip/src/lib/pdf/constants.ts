export const PDF_CONSTANTS = {
  // A4 dimensions in points (72 points = 1 inch)
  A4_WIDTH: 595, // 8.27 inches * 72
  A4_HEIGHT: 842, // 11.69 inches * 72
  
  // Maximum preview width in pixels
  MAX_PREVIEW_WIDTH: 795, // Slightly larger than A4 width to account for padding
  
  // Default QR code size in points
  DEFAULT_QR_SIZE: 100,
  
  // Minimum and maximum QR sizes in points
  MIN_QR_SIZE: 50,
  MAX_QR_SIZE: 200,

  // Aspect ratio of A4 paper
  A4_ASPECT_RATIO: 842 / 595 // height / width
};
