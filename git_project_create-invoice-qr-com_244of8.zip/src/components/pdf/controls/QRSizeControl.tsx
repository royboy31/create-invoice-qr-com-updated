import React from 'react';
import { Minus, Plus } from 'lucide-react';

interface QRSizeControlProps {
  size: number;
  onSizeChange: (size: number) => void;
  min?: number;
  max?: number;
}

export default function QRSizeControl({
  size,
  onSizeChange,
  min = 50,
  max = 200
}: QRSizeControlProps) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-sm text-gray-600">QR Size:</span>
      <button
        onClick={() => onSizeChange(Math.max(min, size - 10))}
        className="p-1 hover:bg-gray-100 rounded"
        disabled={size <= min}
      >
        <Minus className="w-4 h-4" />
      </button>
      <span className="text-sm text-gray-600 min-w-[3ch] text-center">
        {size}
      </span>
      <button
        onClick={() => onSizeChange(Math.min(max, size + 10))}
        className="p-1 hover:bg-gray-100 rounded"
        disabled={size >= max}
      >
        <Plus className="w-4 h-4" />
      </button>
    </div>
  );
}
