import React, { useCallback } from 'react';
import { FileText, Upload } from 'lucide-react';
import ErrorDisplay from '../common/ErrorDisplay';
import { useLanguage } from '../../contexts/LanguageContext';

interface PDFUploaderProps {
  onUpload: (event: React.ChangeEvent<HTMLInputElement> | File) => void;
  loading: boolean;
  error: string | null;
  onErrorDismiss: () => void;
}

export default function PDFUploader({ 
  onUpload, 
  loading, 
  error, 
  onErrorDismiss 
}: PDFUploaderProps) {
  const { t } = useLanguage();

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();

    if (loading) return;

    const file = e.dataTransfer.files[0];
    if (file?.type === 'application/pdf') {
      onUpload(file);
    }
  }, [loading, onUpload]);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  return (
    <>
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        className={`border-2 border-dashed border-gray-800 rounded-lg p-8 transition-colors
          ${loading ? 'opacity-50 cursor-not-allowed' : 'hover:border-indigo-500 cursor-pointer'}`}
      >
        <div className="text-center">
          <FileText className="mx-auto h-12 w-12 text-[#86868b]" />
          <div className="mt-4">
            <label className={`cursor-pointer ${loading ? 'cursor-not-allowed' : ''}`}>
              <span className="mt-2 block text-sm font-medium text-[#c8c2bd]">
                {loading ? t('common.processing') : (
                  <>
                    <Upload className="w-4 h-4 inline-block mr-2" />
                    {t('common.dragAndDrop')}
                  </>
                )}
              </span>
              <input
                type="file"
                className="hidden"
                accept=".pdf"
                onChange={(e) => onUpload(e)}
                disabled={loading}
              />
            </label>
          </div>
        </div>
      </div>

      {error && (
        <ErrorDisplay 
          message={error} 
          onDismiss={onErrorDismiss}
        />
      )}
    </>
  );
}
