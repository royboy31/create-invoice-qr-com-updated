export interface SearchResult {
  id: string;
  title: string;
  description: string;
  path: string;
  keywords: string[];
}
