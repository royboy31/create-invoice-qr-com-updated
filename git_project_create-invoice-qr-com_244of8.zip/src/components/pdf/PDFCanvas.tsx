import React, { useEffect, useRef } from 'react';
import { loadPDF, renderPDFPage } from '../../lib/pdf/loader';
import type { PDFDimensions } from '../../lib/pdf/types';
import { PDF_CONSTANTS } from '../../lib/pdf/constants';

interface PDFCanvasProps {
  pdfData: ArrayBuffer;
  maxWidth?: number;
  onLoad?: (dimensions: PDFDimensions, originalDimensions: PDFDimensions) => void;
  onError?: (error: string) => void;
}

export default function PDFCanvas({ 
  pdfData, 
  maxWidth = PDF_CONSTANTS.MAX_PREVIEW_WIDTH,
  onLoad, 
  onError 
}: PDFCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const pdfRef = useRef<any>(null);

  useEffect(() => {
    let mounted = true;

    const renderPDF = async () => {
      if (!canvasRef.current || !containerRef.current) return;

      try {
        const { pdf, dimensions, originalDimensions } = await loadPDF(pdfData, {
          maxWidth
        });
        
        if (!mounted) {
          await pdf.destroy();
          return;
        }

        pdfRef.current = pdf;
        
        // Get container dimensions
        const containerWidth = containerRef.current.clientWidth;
        const containerHeight = containerRef.current.clientHeight;

        // Calculate scale to fit width while maintaining aspect ratio
        const scale = Math.min(
          containerWidth / originalDimensions.width,
          containerHeight / originalDimensions.height
        );

        // Set canvas dimensions
        const scaledWidth = originalDimensions.width * scale;
        const scaledHeight = originalDimensions.height * scale;

        canvasRef.current.width = scaledWidth;
        canvasRef.current.height = scaledHeight;
        
        await renderPDFPage(canvasRef.current, pdf, 1, scale);
        
        if (mounted && onLoad) {
          onLoad({
            width: scaledWidth,
            height: scaledHeight
          }, originalDimensions);
        }
      } catch (error) {
        console.error('Error rendering PDF:', error);
        if (mounted && onError) {
          onError(error instanceof Error ? error.message : 'Failed to render PDF');
        }
      }
    };

    renderPDF();

    return () => {
      mounted = false;
      if (pdfRef.current?.destroy) {
        pdfRef.current.destroy().catch(console.error);
      }
    };
  }, [pdfData, onLoad, onError, maxWidth]);

  return (
    <div 
      ref={containerRef}
      className="relative w-full h-full overflow-hidden bg-gray-100 rounded-lg"
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}
    >
      <canvas 
        ref={canvasRef}
        className="max-w-full max-h-full object-contain"
        style={{
          width: 'auto',
          height: 'auto'
        }}
      />
    </div>
  );
}
