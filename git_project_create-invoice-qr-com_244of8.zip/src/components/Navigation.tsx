import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { QrCode, Search, User } from 'lucide-react';
import SearchModal from './search/SearchModal';

export default function Navigation() {
  const navigate = useNavigate();
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 bg-black/30 backdrop-blur-md border-b border-gray-800">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-12">
          <div className="flex items-center justify-between h-20">
            <div className="flex-1 flex justify-start">
              {/* Invoice button removed */}
            </div>
            
            <div className="flex-1 flex justify-center">
              <div 
                className="cursor-pointer flex flex-col items-center"
                onClick={() => navigate('/')}
              >
                <QrCode className="h-8 w-8 text-[#fffaf6]" />
                <span className="mt-1 text-xs uppercase tracking-widest font-medium text-[#c8c2bd]">
                  QR Generator
                </span>
              </div>
            </div>

            <div className="flex-1 flex justify-end gap-6">
              <button 
                onClick={() => setIsSearchOpen(true)}
                className="text-[#c8c2bd] hover:text-white transition-colors"
              >
                <Search className="h-6 w-6" />
              </button>
              <button className="text-[#c8c2bd] hover:text-white transition-colors">
                <User className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <SearchModal 
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
      />
    </>
  );
}
