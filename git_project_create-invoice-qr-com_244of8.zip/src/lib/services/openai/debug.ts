// Debug utility for OpenAI responses
export interface DebugResponse {
  timestamp: string;
  prompt: string;
  response: string;
  success: boolean;
  error?: string;
}

const DEBUG_KEY = 'openai_debug_responses';

export function saveDebugResponse(data: DebugResponse) {
  try {
    const stored = localStorage.getItem(DEBUG_KEY);
    const responses = stored ? JSON.parse(stored) : [];
    responses.unshift(data);
    
    // Keep last 10 responses
    const trimmed = responses.slice(0, 10);
    localStorage.setItem(DEBUG_KEY, JSON.stringify(trimmed));
  } catch (error) {
    console.error('Failed to save debug response:', error);
  }
}

export function getDebugResponses(): DebugResponse[] {
  try {
    const stored = localStorage.getItem(DEBUG_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Failed to get debug responses:', error);
    return [];
  }
}

export function clearDebugResponses() {
  localStorage.removeItem(DEBUG_KEY);
}
