import { useState, useCallback, RefObject } from 'react';

interface UseDragAndDropProps {
  containerRef: RefObject<HTMLDivElement>;
  onPositionChange: (position: { x: number; y: number } | null) => void;
}

export function useDragAndDrop({
  containerRef,
  onPositionChange,
}: UseDragAndDropProps) {
  const [isDragging, setIsDragging] = useState(false);

  const calculatePosition = useCallback(
    (clientX: number, clientY: number) => {
      const container = containerRef.current;
      if (!container) return null;

      const rect = container.getBoundingClientRect();
      const scale = parseFloat(container.style.transform?.match(/scale\((.*?)\)/)?.[1] || '1');
      
      const x = ((clientX - rect.left) / (rect.width * scale)) * 100;
      const y = ((clientY - rect.top) / (rect.height * scale)) * 100;

      // Constrain to boundaries with padding
      const padding = 5;
      return {
        x: Math.max(padding, Math.min(100 - padding, x)),
        y: Math.max(padding, Math.min(100 - padding, y))
      };
    },
    [containerRef]
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    setIsDragging(true);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    // Only handle QR code drops
    if (e.dataTransfer.getData('application/qr-code') !== 'true') return;

    const position = calculatePosition(e.clientX, e.clientY);
    if (position) {
      onPositionChange(position);
    }
  }, [calculatePosition, onPositionChange]);

  const handleClick = useCallback((e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      const position = calculatePosition(e.clientX, e.clientY);
      if (position) {
        onPositionChange(position);
      }
    }
  }, [calculatePosition, onPositionChange]);

  return {
    isDragging,
    handlers: {
      onDragOver: handleDragOver,
      onDrop: handleDrop,
      onClick: handleClick,
      onDragEnter: () => setIsDragging(true),
      onDragLeave: (e: React.DragEvent) => {
        if (!e.currentTarget.contains(e.relatedTarget as Node)) {
          setIsDragging(false);
        }
      }
    }
  };
}
