import React from 'react';
import Header from './components/Header';
import InvoiceProcessor from './components/InvoiceProcessor';
import { LanguageProvider } from './contexts/LanguageContext';
import MobileMessage from './components/MobileMessage';

export default function App() {
  return (
    <LanguageProvider>
      <div className="min-h-screen bg-black text-[#c8c2bd]">
        <div className="bg-glow"></div>
        <Header />
        <main className="relative z-10 max-w-[1440px] mx-auto px-6 lg:px-12 py-8">
          <InvoiceProcessor />
          <MobileMessage />
        </main>
      </div>
    </LanguageProvider>
  );
}
