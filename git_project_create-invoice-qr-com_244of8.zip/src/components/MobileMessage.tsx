import React from 'react';

const MobileMessage: React.FC = () => {
  return (
    <div className="mobile-message">
      <div className="mobile-message-content">
        <h2 className="text-xl font-bold text-[#fffaf6] mb-4">
          Mobile Version Coming Soon!
        </h2>
        <p className="text-[#c8c2bd] mb-2">
          We're working hard to bring you a great mobile experience.
        </p>
        <p className="text-[#c8c2bd] mb-2">
          For now, please use a desktop or laptop to access all features.
        </p>
        <p className="text-[#86868b]">
          Thank you for your patience!
        </p>
      </div>
    </div>
  );
};

export default MobileMessage;
