import { EmailData } from '../../types';

export function generateEmailString(data: EmailData): string {
  if (!data.email) throw new Error('Email address is required');
  
  const subject = encodeURIComponent(data.subject || '');
  const body = encodeURIComponent(data.body || '');
  
  return `mailto:${data.email}?subject=${subject}&body=${body}`;
}
