export function validatePaymentData(name: string, iban: string, amount: number) {
  const errors: string[] = [];

  // Validate name
  if (!name?.trim()) {
    errors.push('Recipient name is required');
  } else if (name.length > 70) {
    errors.push('Recipient name must be less than 70 characters');
  }

  // Validate IBAN
  if (!iban?.trim()) {
    errors.push('IBAN is required');
  } else {
    const cleanIban = iban.replace(/\s+/g, '');
    if (!/^[A-Z]{2}[0-9A-Z]{13,32}$/.test(cleanIban)) {
      errors.push('Invalid IBAN format');
    }
  }

  // Validate amount
  if (typeof amount !== 'number' || isNaN(amount)) {
    errors.push('Amount must be a valid number');
  } else if (amount <= 0) {
    errors.push('Amount must be greater than 0');
  } else if (amount > 999999999.99) {
    errors.push('Amount is too large');
  }

  return errors;
}
