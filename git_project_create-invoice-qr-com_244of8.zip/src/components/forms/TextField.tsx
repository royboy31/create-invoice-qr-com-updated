import React from 'react';

interface TextFieldProps {
  text: string;
  onChange: (text: string) => void;
}

export default function TextField({ text, onChange }: TextFieldProps) {
  return (
    <div className="relative">
      <textarea
        value={text}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Enter your text message"
        rows={6}
        className="w-full px-4 py-2.5 text-sm bg-black/50 border border-gray-800 rounded-lg focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 text-[#c8c2bd]"
      />
    </div>
  );
}
