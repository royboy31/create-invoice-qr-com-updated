import * as pdfjsLib from 'pdfjs-dist';
import { PDFDimensions, PDFLoadOptions, PDFError } from './types';
import './worker';

export async function loadPDF(
  pdfData: ArrayBuffer,
  options: PDFLoadOptions = {}
): Promise<{
  pdf: pdfjsLib.PDFDocumentProxy;
  dimensions: PDFDimensions;
  originalDimensions: PDFDimensions;
}> {
  try {
    const pdfDataCopy = pdfData.slice(0);
    const pdfDataArray = new Uint8Array(pdfDataCopy);
    
    const loadingTask = pdfjsLib.getDocument({
      data: pdfDataArray,
      cMapUrl: 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.0.379/cmaps/',
      cMapPacked: true,
    });

    const pdf = await loadingTask.promise;
    const page = await pdf.getPage(1);
    const viewport = page.getViewport({ scale: 1.0 });
    
    // Store original dimensions
    const originalDimensions = {
      width: viewport.width,
      height: viewport.height
    };
    
    // Calculate display dimensions
    const containerWidth = options.maxWidth || 800;
    const scale = containerWidth / viewport.width;
    const scaledViewport = page.getViewport({ scale });

    return {
      pdf,
      dimensions: {
        width: scaledViewport.width,
        height: scaledViewport.height
      },
      originalDimensions
    };
  } catch (error) {
    console.error('Error loading PDF:', error);
    throw new Error('Failed to load PDF document. Please try again.');
  }
}

export async function renderPDFPage(
  canvas: HTMLCanvasElement,
  pdf: pdfjsLib.PDFDocumentProxy,
  pageNumber: number = 1,
  scale: number = 1.0
): Promise<void> {
  try {
    const page = await pdf.getPage(pageNumber);
    const viewport = page.getViewport({ scale });
    
    const context = canvas.getContext('2d');
    if (!context) {
      throw new Error('Could not get canvas context');
    }

    canvas.width = viewport.width;
    canvas.height = viewport.height;

    await page.render({
      canvasContext: context,
      viewport,
      intent: 'display'
    }).promise;
  } catch (error) {
    console.error('Error rendering PDF page:', error);
    throw new Error('Failed to render PDF page. Please try again.');
  }
}
