export interface PaymentData {
  name: string;
  iban: string;
  amount: number;
  reference?: string;
  currency: string;
  bic?: string;
}
