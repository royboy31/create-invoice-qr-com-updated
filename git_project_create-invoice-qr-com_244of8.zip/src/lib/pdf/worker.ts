import { GlobalWorkerOptions } from 'pdfjs-dist';

// Use the bundled worker from the pdf.js package
GlobalWorkerOptions.workerSrc = new URL(
  'pdfjs-dist/build/pdf.worker.mjs',
  import.meta.url
).href;
